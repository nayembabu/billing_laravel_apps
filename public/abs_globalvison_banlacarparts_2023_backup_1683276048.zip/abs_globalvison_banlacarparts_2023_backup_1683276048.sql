

CREATE TABLE `accounts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `account_no` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `initial_balance` double DEFAULT NULL,
  `total_balance` double NOT NULL,
  `note` text COLLATE utf8mb4_unicode_ci,
  `is_default` tinyint(1) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO accounts VALUES("1","123456789","Bikash","1000","1000","","0","0","2018-12-17 19:58:02","2023-03-21 17:49:35");
INSERT INTO accounts VALUES("3","987654321","Nagad","1000","1000","","0","0","2018-12-17 19:58:56","2023-03-21 17:49:26");
INSERT INTO accounts VALUES("5","loyds bank","loyds bank","10000","10000","","1","1","2023-03-21 17:47:40","2023-04-03 13:07:25");
INSERT INTO accounts VALUES("6","Capital on tap","credit card","3000","3000","","","1","2023-03-21 17:48:19","2023-03-21 17:48:19");
INSERT INTO accounts VALUES("7","Co operative bank","ambs","2000","2000","","0","1","2023-03-21 17:48:51","2023-03-27 12:01:06");
INSERT INTO accounts VALUES("8","Barclays business","barclays","0","0","","","1","2023-03-21 17:49:18","2023-03-21 17:49:51");
INSERT INTO accounts VALUES("9","Loan Account","Shahab Fr","5000","5000","Short time loan","0","1","2023-03-22 10:47:47","2023-03-27 11:38:34");
INSERT INTO accounts VALUES("10","SWEET TRADERS","SWEET TRADERS","0","0","","","1","2023-03-27 15:09:11","2023-03-27 15:09:30");



CREATE TABLE `adjustments` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `reference_no` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `warehouse_id` int(11) NOT NULL,
  `document` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `total_qty` double NOT NULL,
  `item` int(11) NOT NULL,
  `note` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;




CREATE TABLE `attendances` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `employee_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `checkin` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `checkout` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` int(11) NOT NULL,
  `note` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;




CREATE TABLE `billers` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `company_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `vat_number` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone_number` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `city` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `state` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `postal_code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `country` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO billers VALUES("1","yousuf","aks.jpg","aks","31123","yousuf@kds.com","442343324","halishahar","chittagong","","","sdgs","0","2018-05-12 14:49:30","2023-03-17 17:12:40");
INSERT INTO billers VALUES("2","tariq","","big tree","","tariq@bigtree.com","321312","khulshi","chittagong","","","","0","2018-05-12 14:57:54","2023-03-17 17:12:40");
INSERT INTO billers VALUES("3","test","","test","","test@test.com","3211","erewrwqre","afsf","","","","0","2018-05-29 19:38:58","2018-05-29 19:39:57");
INSERT INTO billers VALUES("5","modon","mogaTel.jpg","mogaTel","","modon@gmail.com","32321","nasirabad","chittagong","","","bd","0","2018-08-31 20:59:54","2023-03-17 17:12:40");
INSERT INTO billers VALUES("6","a","","a","","a@a.com","q","q","q","","","","0","2018-10-06 19:33:39","2018-10-06 19:34:18");
INSERT INTO billers VALUES("7","a","","a","","a@a.com","a","a","a","","","","0","2018-10-06 19:34:36","2018-10-06 19:36:07");
INSERT INTO billers VALUES("8","x","x.png","x","","x@x.com","x","x","x","","","","0","2019-03-18 04:02:42","2022-11-20 22:09:46");
INSERT INTO billers VALUES("9","Kaiser Iqbal","Largeit.jpeg","Largeit","","kaiseriqbal1990@gmail.com","123456789","Dhaka","Dhaka","","","Bangladesh","0","2023-03-17 17:13:16","2023-03-21 23:07:40");
INSERT INTO billers VALUES("10","Mahir Faisal","BanglacarpartsUKLtd.jpeg","Bangla carparts UK Ltd.","","banglacarparts@gmail.com","07947258297","Unit 6, 153-155 Ley Street","Ilford","Essex","IG1 4Bl","United Kingdom","1","2023-03-21 23:05:13","2023-03-21 23:05:13");
INSERT INTO billers VALUES("11","Md Shamim Ahmed","Banglacar.jpeg","Bangla car","","info@banglacarparts.com","07739371171","Unit 6","Ilford","Essex","IG1 4Bl","United Kingdom","1","2023-03-21 23:10:52","2023-03-21 23:10:52");
INSERT INTO billers VALUES("12","test","","test","","nbjhjjknknkn@gmail.com","07947258297","78 Brisbane Road","Ilford","Essex","IG1 4sl","United Kingdom","0","2023-04-10 15:07:04","2023-04-10 15:56:23");
INSERT INTO billers VALUES("13","AAAH Enterprise LTD.","","AAAH Enterprise LTD.","","aaah@gmail.com","07459003948","84B Woodlands Road","Barking","Essex","IG1 1JW","UK","1","2023-04-12 11:32:23","2023-04-12 11:32:23");
INSERT INTO billers VALUES("14","Md Nazrul Islam (Tutul)","","Md Nazrul Islam (Tutul)","","islamn207@yahoo.com","+447525731312","349A Halley Road","London","","E12 6UB","UK","1","2023-04-19 14:21:49","2023-04-19 14:21:49");
INSERT INTO billers VALUES("15","SM Kamruzzaman Uzi","","Bangla Car Parts BD","","uzi11918@gmail.com","07947303703","Mirpur, Dhaka","Dhaka","","","Bangladesh","1","2023-04-24 15:47:54","2023-04-24 15:47:54");



CREATE TABLE `brands` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=306 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO brands VALUES("3","HP","HP.jpg","0","2018-05-12 02:06:14","2023-03-21 23:12:51");
INSERT INTO brands VALUES("4","samsung","samsung.jpg","0","2018-05-12 02:08:41","2023-03-21 23:12:56");
INSERT INTO brands VALUES("5","Apple","Apple.jpg","0","2018-08-31 16:34:49","2023-03-21 23:13:03");
INSERT INTO brands VALUES("6","jjjj","20201019093419.jpg","0","2020-10-19 08:33:52","2020-10-19 08:35:58");
INSERT INTO brands VALUES("7","Lotto","","0","2020-11-15 21:13:41","2023-03-17 17:23:15");
INSERT INTO brands VALUES("8","cocacola","","0","2022-01-12 06:26:22","2022-01-12 06:26:30");
INSERT INTO brands VALUES("9","pepsi","20220112072659.jpg","0","2022-01-12 06:26:59","2022-01-12 06:27:07");
INSERT INTO brands VALUES("10","Audi","20230321111824.png","0","2023-03-21 23:18:24","2023-05-02 13:38:04");
INSERT INTO brands VALUES("11","BMW","20230321111842.jpeg","0","2023-03-21 23:18:42","2023-05-02 13:38:04");
INSERT INTO brands VALUES("12","Bentley","20230321111906.jpeg","0","2023-03-21 23:19:06","2023-05-02 13:38:04");
INSERT INTO brands VALUES("13","Porsche","20230321111930.png","0","2023-03-21 23:19:30","2023-05-02 13:38:04");
INSERT INTO brands VALUES("14","Mercedez benz","20230321111950.jpeg","0","2023-03-21 23:19:50","2023-05-02 13:38:04");
INSERT INTO brands VALUES("15","Land rover","20230321112034.png","0","2023-03-21 23:20:34","2023-05-02 13:38:04");
INSERT INTO brands VALUES("16","Toyota","20230321112110.jpeg","0","2023-03-21 23:21:10","2023-05-02 13:38:04");
INSERT INTO brands VALUES("17","Tesla","20230321112148.png","0","2023-03-21 23:21:48","2023-05-02 13:38:04");
INSERT INTO brands VALUES("18","Volvo","20230321112305.jpeg","0","2023-03-21 23:23:05","2023-05-02 13:38:04");
INSERT INTO brands VALUES("19","ALBERTO BALSAM","","1","2023-04-19 14:48:45","2023-04-19 14:48:45");
INSERT INTO brands VALUES("20","aquafresh","","1","2023-05-02 13:37:43","2023-05-02 16:48:24");
INSERT INTO brands VALUES("21","COLGATE","","1","2023-05-02 13:37:43","2023-05-02 16:48:24");
INSERT INTO brands VALUES("22","AVEENO","","1","2023-05-02 13:37:43","2023-05-02 16:48:24");
INSERT INTO brands VALUES("23","BIODERMA","","1","2023-05-02 13:37:43","2023-05-02 16:48:24");
INSERT INTO brands VALUES("24","Boots","","1","2023-05-02 13:37:43","2023-05-02 16:48:24");
INSERT INTO brands VALUES("25","BRUT","","1","2023-05-02 13:37:43","2023-05-02 16:48:24");
INSERT INTO brands VALUES("26","CLEAN & CLEAR","","1","2023-05-02 13:37:43","2023-05-02 16:48:24");
INSERT INTO brands VALUES("27","DOVE","","1","2023-05-02 13:37:43","2023-05-02 16:48:24");
INSERT INTO brands VALUES("28","oral B","","1","2023-05-02 13:37:43","2023-05-02 16:48:24");
INSERT INTO brands VALUES("29","st.Ives","","1","2023-05-02 13:37:43","2023-05-02 16:48:24");
INSERT INTO brands VALUES("30","tresemme","","1","2023-05-02 13:37:43","2023-05-02 16:48:24");
INSERT INTO brands VALUES("31","johnsons","","1","2023-05-02 13:37:43","2023-05-02 16:48:24");
INSERT INTO brands VALUES("32","loreal","","1","2023-05-02 13:37:43","2023-05-02 16:48:24");
INSERT INTO brands VALUES("33","neutrogena","","1","2023-05-02 13:37:43","2023-05-02 16:48:24");
INSERT INTO brands VALUES("34","nivea","","1","2023-05-02 13:37:43","2023-05-02 16:48:24");
INSERT INTO brands VALUES("35","palmolive","","1","2023-05-02 13:37:43","2023-05-02 16:48:24");
INSERT INTO brands VALUES("36","pantene","","1","2023-05-02 13:37:43","2023-05-02 16:48:24");
INSERT INTO brands VALUES("37","vaseline","","1","2023-05-02 13:37:43","2023-05-02 16:48:24");
INSERT INTO brands VALUES("38","KIT KAT","20230502021236.png","1","2023-05-02 14:10:08","2023-05-02 14:12:36");
INSERT INTO brands VALUES("39","","","1","2023-05-02 16:42:40","2023-05-02 16:43:14");
INSERT INTO brands VALUES("40","Technic","iphone.jpg","1","2023-05-02 16:48:23","2023-05-02 16:48:23");
INSERT INTO brands VALUES("41","Al-Fakhr Perfumes","","1","2023-05-02 16:48:23","2023-05-02 16:48:23");
INSERT INTO brands VALUES("42","Khalis","","1","2023-05-02 16:48:23","2023-05-02 16:48:23");
INSERT INTO brands VALUES("43","Real Time","","1","2023-05-02 16:48:23","2023-05-02 16:48:23");
INSERT INTO brands VALUES("44","Farzana's","","1","2023-05-02 16:48:23","2023-05-02 16:48:23");
INSERT INTO brands VALUES("45","Ard Al Zaafaran","","1","2023-05-02 16:48:23","2023-05-02 16:48:23");
INSERT INTO brands VALUES("46","Armaf","","1","2023-05-02 16:48:23","2023-05-02 16:48:23");
INSERT INTO brands VALUES("47","Milton Lloyd","","1","2023-05-02 16:48:23","2023-05-02 16:48:23");
INSERT INTO brands VALUES("48","Fogg","","1","2023-05-02 16:48:23","2023-05-02 16:48:23");
INSERT INTO brands VALUES("49","W7","","1","2023-05-02 16:48:23","2023-05-02 16:48:23");
INSERT INTO brands VALUES("50","Union Jack","","1","2023-05-02 16:48:23","2023-05-02 16:48:23");
INSERT INTO brands VALUES("51","Body Collection","","1","2023-05-02 16:48:23","2023-05-02 16:48:23");
INSERT INTO brands VALUES("52","CS Beauty","","1","2023-05-02 16:48:23","2023-05-02 16:48:23");
INSERT INTO brands VALUES("53","L'Oreal","","1","2023-05-02 16:48:23","2023-05-02 16:48:23");
INSERT INTO brands VALUES("54","Lilyz","","1","2023-05-02 16:48:23","2023-05-02 16:48:23");
INSERT INTO brands VALUES("55","London Pride Cosmetics","","1","2023-05-02 16:48:23","2023-05-02 16:48:23");
INSERT INTO brands VALUES("56","Max Factor","","1","2023-05-02 16:48:23","2023-05-02 16:48:23");
INSERT INTO brands VALUES("57","Outdoor Girl","","1","2023-05-02 16:48:23","2023-05-02 16:48:23");
INSERT INTO brands VALUES("58","Real Techniques","","1","2023-05-02 16:48:23","2023-05-02 16:48:23");
INSERT INTO brands VALUES("59","Rimmel","","1","2023-05-02 16:48:23","2023-05-02 16:48:23");
INSERT INTO brands VALUES("60","Royal","","1","2023-05-02 16:48:23","2023-05-02 16:48:23");
INSERT INTO brands VALUES("61","Saffron","","1","2023-05-02 16:48:23","2023-05-02 16:48:23");
INSERT INTO brands VALUES("62","Yurily","","1","2023-05-02 16:48:23","2023-05-02 16:48:23");
INSERT INTO brands VALUES("63","Beauty UK","","1","2023-05-02 16:48:23","2023-05-02 16:48:23");
INSERT INTO brands VALUES("64","e.l.f.","","1","2023-05-02 16:48:23","2023-05-02 16:48:23");
INSERT INTO brands VALUES("65","EcoTools","","1","2023-05-02 16:48:23","2023-05-02 16:48:23");
INSERT INTO brands VALUES("66","Laroc","","1","2023-05-02 16:48:23","2023-05-02 16:48:23");
INSERT INTO brands VALUES("67","Laval","","1","2023-05-02 16:48:23","2023-05-02 16:48:23");
INSERT INTO brands VALUES("68","Z'oreya","","1","2023-05-02 16:48:23","2023-05-02 16:48:23");
INSERT INTO brands VALUES("69","Sunkissed","","1","2023-05-02 16:48:23","2023-05-02 16:48:23");
INSERT INTO brands VALUES("70","Panasonic","","1","2023-05-02 16:48:23","2023-05-02 16:48:23");
INSERT INTO brands VALUES("71","Bourjois","","1","2023-05-02 16:48:23","2023-05-02 16:48:23");
INSERT INTO brands VALUES("72","Deborah Milano","","1","2023-05-02 16:48:23","2023-05-02 16:48:23");
INSERT INTO brands VALUES("73","L. A. Girl","","1","2023-05-02 16:48:23","2023-05-02 16:48:23");
INSERT INTO brands VALUES("74","Luoys Paris","","1","2023-05-02 16:48:23","2023-05-02 16:48:23");
INSERT INTO brands VALUES("75","Manhattan","","1","2023-05-02 16:48:23","2023-05-02 16:48:23");
INSERT INTO brands VALUES("76","Maybelline","","1","2023-05-02 16:48:23","2023-05-02 16:48:23");
INSERT INTO brands VALUES("77","Revlon","","1","2023-05-02 16:48:23","2023-05-02 16:48:23");
INSERT INTO brands VALUES("78","Revolution Makeup","","1","2023-05-02 16:48:23","2023-05-02 16:48:23");
INSERT INTO brands VALUES("79","Active","","1","2023-05-02 16:48:23","2023-05-02 16:48:23");
INSERT INTO brands VALUES("80","Astor","","1","2023-05-02 16:48:23","2023-05-02 16:48:23");
INSERT INTO brands VALUES("81","Barry M","","1","2023-05-02 16:48:23","2023-05-02 16:48:23");
INSERT INTO brands VALUES("82","Ciate London","","1","2023-05-02 16:48:23","2023-05-02 16:48:23");
INSERT INTO brands VALUES("83","City Color","","1","2023-05-02 16:48:23","2023-05-02 16:48:23");
INSERT INTO brands VALUES("84","Collection","","1","2023-05-02 16:48:23","2023-05-02 16:48:23");
INSERT INTO brands VALUES("85","Constance Carroll","","1","2023-05-02 16:48:23","2023-05-02 16:48:23");
INSERT INTO brands VALUES("86","Covergirl","","1","2023-05-02 16:48:23","2023-05-02 16:48:23");
INSERT INTO brands VALUES("87","Delia Cosmetics","","1","2023-05-02 16:48:23","2023-05-02 16:48:23");
INSERT INTO brands VALUES("88","Eveline","","1","2023-05-02 16:48:23","2023-05-02 16:48:23");
INSERT INTO brands VALUES("89","Eylure Cosmetics","","1","2023-05-02 16:48:23","2023-05-02 16:48:23");
INSERT INTO brands VALUES("90","Gallery Cosmetics","","1","2023-05-02 16:48:23","2023-05-02 16:48:23");
INSERT INTO brands VALUES("91","IMAN","","1","2023-05-02 16:48:23","2023-05-02 16:48:23");
INSERT INTO brands VALUES("92","Kiko Milano","","1","2023-05-02 16:48:23","2023-05-02 16:48:23");
INSERT INTO brands VALUES("93","La Femme","","1","2023-05-02 16:48:23","2023-05-02 16:48:23");
INSERT INTO brands VALUES("94","Laura Geller","","1","2023-05-02 16:48:23","2023-05-02 16:48:23");
INSERT INTO brands VALUES("95","Miss Sporty","","1","2023-05-02 16:48:23","2023-05-02 16:48:23");
INSERT INTO brands VALUES("96","Models Own","","1","2023-05-02 16:48:23","2023-05-02 16:48:23");
INSERT INTO brands VALUES("97","MUA Makeup","","1","2023-05-02 16:48:23","2023-05-02 16:48:23");
INSERT INTO brands VALUES("98","N.Y.C.","","1","2023-05-02 16:48:23","2023-05-02 16:48:23");
INSERT INTO brands VALUES("99","NYX","","1","2023-05-02 16:48:23","2023-05-02 16:48:23");
INSERT INTO brands VALUES("100","Sleek","","1","2023-05-02 16:48:23","2023-05-02 16:48:23");
INSERT INTO brands VALUES("101","The Balm","","1","2023-05-02 16:48:23","2023-05-02 16:48:23");
INSERT INTO brands VALUES("102","The Body Shop","","1","2023-05-02 16:48:23","2023-05-02 16:48:23");
INSERT INTO brands VALUES("103","Vivien Kondor","","1","2023-05-02 16:48:23","2023-05-02 16:48:23");
INSERT INTO brands VALUES("104","Elizabeth Arden","","1","2023-05-02 16:48:23","2023-05-02 16:48:23");
INSERT INTO brands VALUES("105","EX1 Cosmetics","","1","2023-05-02 16:48:23","2023-05-02 16:48:23");
INSERT INTO brands VALUES("106","Kylie Jenner","","1","2023-05-02 16:48:23","2023-05-02 16:48:23");
INSERT INTO brands VALUES("107","London Girl","","1","2023-05-02 16:48:23","2023-05-02 16:48:23");
INSERT INTO brands VALUES("108","The Ordinary UK","","1","2023-05-02 16:48:23","2023-05-02 16:48:23");
INSERT INTO brands VALUES("109","Cosmod","","1","2023-05-02 16:48:23","2023-05-02 16:48:23");
INSERT INTO brands VALUES("110","Cover Shoot Cosmetics","","1","2023-05-02 16:48:23","2023-05-02 16:48:23");
INSERT INTO brands VALUES("111","Glamatone","","1","2023-05-02 16:48:23","2023-05-02 16:48:23");
INSERT INTO brands VALUES("112","Janet Cosmetics","","1","2023-05-02 16:48:23","2023-05-02 16:48:23");
INSERT INTO brands VALUES("113","Leichner","","1","2023-05-02 16:48:23","2023-05-02 16:48:23");
INSERT INTO brands VALUES("114","Milani","","1","2023-05-02 16:48:23","2023-05-02 16:48:23");
INSERT INTO brands VALUES("115","Philosophy","","1","2023-05-02 16:48:23","2023-05-02 16:48:23");
INSERT INTO brands VALUES("116","Trinny London","","1","2023-05-02 16:48:23","2023-05-02 16:48:23");
INSERT INTO brands VALUES("117","Vita Liberata","","1","2023-05-02 16:48:23","2023-05-02 16:48:23");
INSERT INTO brands VALUES("118","Amazing Shine","","1","2023-05-02 16:48:23","2023-05-02 16:48:23");
INSERT INTO brands VALUES("119","Naseem","","1","2023-05-02 16:48:23","2023-05-02 16:48:23");
INSERT INTO brands VALUES("120","Omerta","","1","2023-05-02 16:48:23","2023-05-02 16:48:23");
INSERT INTO brands VALUES("121","Jean Paul Gaultier","","1","2023-05-02 16:48:23","2023-05-02 16:48:23");
INSERT INTO brands VALUES("122","James Bond 007","","1","2023-05-02 16:48:23","2023-05-02 16:48:23");
INSERT INTO brands VALUES("123","Perfume Inspired","","1","2023-05-02 16:48:23","2023-05-02 16:48:23");
INSERT INTO brands VALUES("124","Lamis","","1","2023-05-02 16:48:23","2023-05-02 16:48:23");
INSERT INTO brands VALUES("125","New Brand","","1","2023-05-02 16:48:23","2023-05-02 16:48:23");
INSERT INTO brands VALUES("126","John Allen","","1","2023-05-02 16:48:23","2023-05-02 16:48:23");
INSERT INTO brands VALUES("127","Carolina Herrera","","1","2023-05-02 16:48:23","2023-05-02 16:48:23");
INSERT INTO brands VALUES("128","Hamidi - Sterling","","1","2023-05-02 16:48:23","2023-05-02 16:48:23");
INSERT INTO brands VALUES("129","Manasik","","1","2023-05-02 16:48:23","2023-05-02 16:48:23");
INSERT INTO brands VALUES("130","Insignia","","1","2023-05-02 16:48:23","2023-05-02 16:48:23");
INSERT INTO brands VALUES("131","Chris Adams","","1","2023-05-02 16:48:23","2023-05-02 16:48:23");
INSERT INTO brands VALUES("132","Linn Young","","1","2023-05-02 16:48:23","2023-05-02 16:48:23");
INSERT INTO brands VALUES("133","Al-Rehab","","1","2023-05-02 16:48:23","2023-05-02 16:48:23");
INSERT INTO brands VALUES("134","Ard Al Rehan","","1","2023-05-02 16:48:23","2023-05-02 16:48:23");
INSERT INTO brands VALUES("135","JpD","","1","2023-05-02 16:48:23","2023-05-02 16:48:23");
INSERT INTO brands VALUES("136","Nusuk","","1","2023-05-02 16:48:23","2023-05-02 16:48:23");
INSERT INTO brands VALUES("137","Ahsan Perfumes","","1","2023-05-02 16:48:23","2023-05-02 16:48:23");
INSERT INTO brands VALUES("138","RiiFFS","","1","2023-05-02 16:48:23","2023-05-02 16:48:23");
INSERT INTO brands VALUES("139","Rihanah","","1","2023-05-02 16:48:23","2023-05-02 16:48:23");
INSERT INTO brands VALUES("140","Fine Perfumery","","1","2023-05-02 16:48:23","2023-05-02 16:48:23");
INSERT INTO brands VALUES("141","Swiss Arabian","","1","2023-05-02 16:48:23","2023-05-02 16:48:23");
INSERT INTO brands VALUES("142","Areen","","1","2023-05-02 16:48:23","2023-05-02 16:48:23");
INSERT INTO brands VALUES("143","Georges Mezotti","","1","2023-05-02 16:48:23","2023-05-02 16:48:23");
INSERT INTO brands VALUES("144","Creative Colours Ltd","","1","2023-05-02 16:48:23","2023-05-02 16:48:23");
INSERT INTO brands VALUES("145","Rapport","","1","2023-05-02 16:48:23","2023-05-02 16:48:23");
INSERT INTO brands VALUES("146","Sapil","","1","2023-05-02 16:48:23","2023-05-02 16:48:23");
INSERT INTO brands VALUES("147","Hugo Boss","","1","2023-05-02 16:48:23","2023-05-02 16:48:23");
INSERT INTO brands VALUES("148","World of jass","","1","2023-05-02 16:48:23","2023-05-02 16:48:23");
INSERT INTO brands VALUES("149","Real Image Perfumes","","1","2023-05-02 16:48:23","2023-05-02 16:48:23");
INSERT INTO brands VALUES("150","Fragrance World","","1","2023-05-02 16:48:23","2023-05-02 16:48:23");
INSERT INTO brands VALUES("151","Burberry","","1","2023-05-02 16:48:23","2023-05-02 16:48:23");
INSERT INTO brands VALUES("152","Laurelle Parfums","","1","2023-05-02 16:48:23","2023-05-02 16:48:23");
INSERT INTO brands VALUES("153","D & M","","1","2023-05-02 16:48:23","2023-05-02 16:48:23");
INSERT INTO brands VALUES("154","Cerruti","","1","2023-05-02 16:48:23","2023-05-02 16:48:23");
INSERT INTO brands VALUES("155","Davidoff","","1","2023-05-02 16:48:23","2023-05-02 16:48:23");
INSERT INTO brands VALUES("156","Calvin Klein","","1","2023-05-02 16:48:23","2023-05-02 16:48:23");
INSERT INTO brands VALUES("157","Classic Collection","","1","2023-05-02 16:48:23","2023-05-02 16:48:23");
INSERT INTO brands VALUES("158","David Beckham","","1","2023-05-02 16:48:23","2023-05-02 16:48:23");
INSERT INTO brands VALUES("159","Flavia","","1","2023-05-02 16:48:23","2023-05-02 16:48:23");
INSERT INTO brands VALUES("160","Lacoste","","1","2023-05-02 16:48:23","2023-05-02 16:48:23");
INSERT INTO brands VALUES("161","Lattafa","","1","2023-05-02 16:48:23","2023-05-02 16:48:23");
INSERT INTO brands VALUES("162","Just Jack","","1","2023-05-02 16:48:23","2023-05-02 16:48:23");
INSERT INTO brands VALUES("163","Alta Moda","","1","2023-05-02 16:48:23","2023-05-02 16:48:23");
INSERT INTO brands VALUES("164","Issey Miyake","","1","2023-05-02 16:48:23","2023-05-02 16:48:23");
INSERT INTO brands VALUES("165","Shirley May","","1","2023-05-02 16:48:23","2023-05-02 16:48:23");
INSERT INTO brands VALUES("166","Al Arabia Perfumes","","1","2023-05-02 16:48:23","2023-05-02 16:48:23");
INSERT INTO brands VALUES("167","Ford","","1","2023-05-02 16:48:23","2023-05-02 16:48:23");
INSERT INTO brands VALUES("168","Suroori","","1","2023-05-02 16:48:23","2023-05-02 16:48:23");
INSERT INTO brands VALUES("169","Lambretta","","1","2023-05-02 16:48:23","2023-05-02 16:48:23");
INSERT INTO brands VALUES("170","Paco Rabanne","","1","2023-05-02 16:48:23","2023-05-02 16:48:23");
INSERT INTO brands VALUES("171","Racing Green","","1","2023-05-02 16:48:23","2023-05-02 16:48:23");
INSERT INTO brands VALUES("172","Tiverton","","1","2023-05-02 16:48:23","2023-05-02 16:48:23");
INSERT INTO brands VALUES("173","Sterling","","1","2023-05-02 16:48:23","2023-05-02 16:48:23");
INSERT INTO brands VALUES("174","Eyvoke","","1","2023-05-02 16:48:23","2023-05-02 16:48:23");
INSERT INTO brands VALUES("175","Fortunate Fashion & Passion","","1","2023-05-02 16:48:23","2023-05-02 16:48:23");
INSERT INTO brands VALUES("176","Fragrance Couture","","1","2023-05-02 16:48:23","2023-05-02 16:48:23");
INSERT INTO brands VALUES("177","Airpure","","1","2023-05-02 16:48:23","2023-05-02 16:48:23");
INSERT INTO brands VALUES("178","Bloome","","1","2023-05-02 16:48:23","2023-05-02 16:48:23");
INSERT INTO brands VALUES("179","Pan Aroma","","1","2023-05-02 16:48:23","2023-05-02 16:48:23");
INSERT INTO brands VALUES("180","Nuage","","1","2023-05-02 16:48:23","2023-05-02 16:48:23");
INSERT INTO brands VALUES("181","Style and Grace","","1","2023-05-02 16:48:23","2023-05-02 16:48:23");
INSERT INTO brands VALUES("182","7th  Heaven","","1","2023-05-02 16:48:23","2023-05-02 16:48:23");
INSERT INTO brands VALUES("183","Beauty Formulas","","1","2023-05-02 16:48:23","2023-05-02 16:48:23");
INSERT INTO brands VALUES("184","Dermav10","","1","2023-05-02 16:48:23","2023-05-02 16:48:23");
INSERT INTO brands VALUES("185","Garnier","","1","2023-05-02 16:48:23","2023-05-02 16:48:23");
INSERT INTO brands VALUES("186","Jolen","","1","2023-05-02 16:48:23","2023-05-02 16:48:23");
INSERT INTO brands VALUES("187","Noughty","","1","2023-05-02 16:48:23","2023-05-02 16:48:23");
INSERT INTO brands VALUES("188","Palmer's","","1","2023-05-02 16:48:23","2023-05-02 16:48:23");
INSERT INTO brands VALUES("189","Simple","","1","2023-05-02 16:48:23","2023-05-02 16:48:23");
INSERT INTO brands VALUES("190","Zacharia Accessories","","1","2023-05-02 16:48:23","2023-05-02 16:48:23");
INSERT INTO brands VALUES("191","Aussie","","1","2023-05-02 16:48:23","2023-05-02 16:48:23");
INSERT INTO brands VALUES("192","Charles Worthington London","","1","2023-05-02 16:48:23","2023-05-02 16:48:23");
INSERT INTO brands VALUES("193","Enliven","","1","2023-05-02 16:48:23","2023-05-02 16:48:23");
INSERT INTO brands VALUES("194","Faith In Nature","","1","2023-05-02 16:48:24","2023-05-02 16:48:24");
INSERT INTO brands VALUES("195","Fudge Urban","","1","2023-05-02 16:48:24","2023-05-02 16:48:24");
INSERT INTO brands VALUES("196","Harmony","","1","2023-05-02 16:48:24","2023-05-02 16:48:24");
INSERT INTO brands VALUES("197","Lief Essentials","","1","2023-05-02 16:48:24","2023-05-02 16:48:24");
INSERT INTO brands VALUES("198","Natura Siberica","","1","2023-05-02 16:48:24","2023-05-02 16:48:24");
INSERT INTO brands VALUES("199","TONI&GUY","","1","2023-05-02 16:48:24","2023-05-02 16:48:24");
INSERT INTO brands VALUES("200","TRESemme'","","1","2023-05-02 16:48:24","2023-05-02 16:48:24");
INSERT INTO brands VALUES("201","La Riche","","1","2023-05-02 16:48:24","2023-05-02 16:48:24");
INSERT INTO brands VALUES("202","Crazy Color","","1","2023-05-02 16:48:24","2023-05-02 16:48:24");
INSERT INTO brands VALUES("203","Rebellious","","1","2023-05-02 16:48:24","2023-05-02 16:48:24");
INSERT INTO brands VALUES("204","Party Success","","1","2023-05-02 16:48:24","2023-05-02 16:48:24");
INSERT INTO brands VALUES("205","Zoflora","","1","2023-05-02 16:48:24","2023-05-02 16:48:24");
INSERT INTO brands VALUES("206","Dr J's Just 4","","1","2023-05-02 16:48:24","2023-05-02 16:48:24");
INSERT INTO brands VALUES("207","Johnson's","","1","2023-05-02 16:48:24","2023-05-02 16:48:24");
INSERT INTO brands VALUES("208","Mustela","","1","2023-05-02 16:48:24","2023-05-02 16:48:24");
INSERT INTO brands VALUES("209","Dorall Collection","","1","2023-05-02 16:48:24","2023-05-02 16:48:24");
INSERT INTO brands VALUES("210","Nabeel","","1","2023-05-02 16:48:24","2023-05-02 16:48:24");
INSERT INTO brands VALUES("211","Cacharel","","1","2023-05-02 16:48:24","2023-05-02 16:48:24");
INSERT INTO brands VALUES("212","Kenzo","","1","2023-05-02 16:48:24","2023-05-02 16:48:24");
INSERT INTO brands VALUES("213","Elite Perfumes","","1","2023-05-02 16:48:24","2023-05-02 16:48:24");
INSERT INTO brands VALUES("214","Giverny","","1","2023-05-02 16:48:24","2023-05-02 16:48:24");
INSERT INTO brands VALUES("215","Jass","","1","2023-05-02 16:48:24","2023-05-02 16:48:24");
INSERT INTO brands VALUES("216","Katy Perry's","","1","2023-05-02 16:48:24","2023-05-02 16:48:24");
INSERT INTO brands VALUES("217","Jimmy Choo","","1","2023-05-02 16:48:24","2023-05-02 16:48:24");
INSERT INTO brands VALUES("218","Eden Classics","","1","2023-05-02 16:48:24","2023-05-02 16:48:24");
INSERT INTO brands VALUES("219","Ajyad","","1","2023-05-02 16:48:24","2023-05-02 16:48:24");
INSERT INTO brands VALUES("220","Dior","","1","2023-05-02 16:48:24","2023-05-02 16:48:24");
INSERT INTO brands VALUES("221","Ghost","","1","2023-05-02 16:48:24","2023-05-02 16:48:24");
INSERT INTO brands VALUES("222","Paloma Picasso","","1","2023-05-02 16:48:24","2023-05-02 16:48:24");
INSERT INTO brands VALUES("223","Black Onyx","","1","2023-05-02 16:48:24","2023-05-02 16:48:24");
INSERT INTO brands VALUES("224","Rituals","","1","2023-05-02 16:48:24","2023-05-02 16:48:24");
INSERT INTO brands VALUES("225","V.V.Love","","1","2023-05-02 16:48:24","2023-05-02 16:48:24");
INSERT INTO brands VALUES("226","Bellapierre","","1","2023-05-02 16:48:24","2023-05-02 16:48:24");
INSERT INTO brands VALUES("227","eos","","1","2023-05-02 16:48:24","2023-05-02 16:48:24");
INSERT INTO brands VALUES("228","Golden Rose","","1","2023-05-02 16:48:24","2023-05-02 16:48:24");
INSERT INTO brands VALUES("229","Top Girl","","1","2023-05-02 16:48:24","2023-05-02 16:48:24");
INSERT INTO brands VALUES("230","Nuxe Paris","","1","2023-05-02 16:48:24","2023-05-02 16:48:24");
INSERT INTO brands VALUES("231","Excilor","","1","2023-05-02 16:48:24","2023-05-02 16:48:24");
INSERT INTO brands VALUES("232","SensatioNail","","1","2023-05-02 16:48:24","2023-05-02 16:48:24");
INSERT INTO brands VALUES("233","Nailoid Results","","1","2023-05-02 16:48:24","2023-05-02 16:48:24");
INSERT INTO brands VALUES("234","Pink Tease","","1","2023-05-02 16:48:24","2023-05-02 16:48:24");
INSERT INTO brands VALUES("235","Sally  Hansen","","1","2023-05-02 16:48:24","2023-05-02 16:48:24");
INSERT INTO brands VALUES("236","Classics","","1","2023-05-02 16:48:24","2023-05-02 16:48:24");
INSERT INTO brands VALUES("237","Personal Protective Equipment","","1","2023-05-02 16:48:24","2023-05-02 16:48:24");
INSERT INTO brands VALUES("238","Addiction","","1","2023-05-02 16:48:24","2023-05-02 16:48:24");
INSERT INTO brands VALUES("239","Moschino","","1","2023-05-02 16:48:24","2023-05-02 16:48:24");
INSERT INTO brands VALUES("240","Jump","","1","2023-05-02 16:48:24","2023-05-02 16:48:24");
INSERT INTO brands VALUES("241","Kleenex","","1","2023-05-02 16:48:24","2023-05-02 16:48:24");
INSERT INTO brands VALUES("242","Masterplast","","1","2023-05-02 16:48:24","2023-05-02 16:48:24");
INSERT INTO brands VALUES("243","NTI","","1","2023-05-02 16:48:24","2023-05-02 16:48:24");
INSERT INTO brands VALUES("244","Olbas","","1","2023-05-02 16:48:24","2023-05-02 16:48:24");
INSERT INTO brands VALUES("245","Oral -B","","1","2023-05-02 16:48:24","2023-05-02 16:48:24");
INSERT INTO brands VALUES("246","Tiger Balm","","1","2023-05-02 16:48:24","2023-05-02 16:48:24");
INSERT INTO brands VALUES("247","Vicks","","1","2023-05-02 16:48:24","2023-05-02 16:48:24");
INSERT INTO brands VALUES("248","Pets Play","","1","2023-05-02 16:48:24","2023-05-02 16:48:24");
INSERT INTO brands VALUES("249","Pride & Groom","","1","2023-05-02 16:48:24","2023-05-02 16:48:24");
INSERT INTO brands VALUES("250","Pure Breed","","1","2023-05-02 16:48:24","2023-05-02 16:48:24");
INSERT INTO brands VALUES("251","Rosewood","","1","2023-05-02 16:48:24","2023-05-02 16:48:24");
INSERT INTO brands VALUES("252","TidyZ","","1","2023-05-02 16:48:24","2023-05-02 16:48:24");
INSERT INTO brands VALUES("253","Creightons","","1","2023-05-02 16:48:24","2023-05-02 16:48:24");
INSERT INTO brands VALUES("254","Fake Bake","","1","2023-05-02 16:48:24","2023-05-02 16:48:24");
INSERT INTO brands VALUES("255","Adidas","","1","2023-05-02 16:48:24","2023-05-02 16:48:24");
INSERT INTO brands VALUES("256","Amplex","","1","2023-05-02 16:48:24","2023-05-02 16:48:24");
INSERT INTO brands VALUES("257","Bell's Healthcare","","1","2023-05-02 16:48:24","2023-05-02 16:48:24");
INSERT INTO brands VALUES("258","Bic","","1","2023-05-02 16:48:24","2023-05-02 16:48:24");
INSERT INTO brands VALUES("259","Bio Glow","","1","2023-05-02 16:48:24","2023-05-02 16:48:24");
INSERT INTO brands VALUES("260","Bio-Oil","","1","2023-05-02 16:48:24","2023-05-02 16:48:24");
INSERT INTO brands VALUES("261","Bloom and Blossom","","1","2023-05-02 16:48:24","2023-05-02 16:48:24");
INSERT INTO brands VALUES("262","Burt's Bees","","1","2023-05-02 16:48:24","2023-05-02 16:48:24");
INSERT INTO brands VALUES("263","Carmex","","1","2023-05-02 16:48:24","2023-05-02 16:48:24");
INSERT INTO brands VALUES("264","Clarins","","1","2023-05-02 16:48:24","2023-05-02 16:48:24");
INSERT INTO brands VALUES("265","Clean Vibes","","1","2023-05-02 16:48:24","2023-05-02 16:48:24");
INSERT INTO brands VALUES("266","Cyclax","","1","2023-05-02 16:48:24","2023-05-02 16:48:24");
INSERT INTO brands VALUES("267","Deep Freeze","","1","2023-05-02 16:48:24","2023-05-02 16:48:24");
INSERT INTO brands VALUES("268","Deep Heat","","1","2023-05-02 16:48:24","2023-05-02 16:48:24");
INSERT INTO brands VALUES("269","Denim","","1","2023-05-02 16:48:24","2023-05-02 16:48:24");
INSERT INTO brands VALUES("270","Dettol","","1","2023-05-02 16:48:24","2023-05-02 16:48:24");
INSERT INTO brands VALUES("271","Dr Botanicals","","1","2023-05-02 16:48:24","2023-05-02 16:48:24");
INSERT INTO brands VALUES("272","Escenti","","1","2023-05-02 16:48:24","2023-05-02 16:48:24");
INSERT INTO brands VALUES("273","Eucryl","","1","2023-05-02 16:48:24","2023-05-02 16:48:24");
INSERT INTO brands VALUES("274","Face Facts","","1","2023-05-02 16:48:24","2023-05-02 16:48:24");
INSERT INTO brands VALUES("275","Freeman","","1","2023-05-02 16:48:24","2023-05-02 16:48:24");
INSERT INTO brands VALUES("276","Fudge","","1","2023-05-02 16:48:24","2023-05-02 16:48:24");
INSERT INTO brands VALUES("277","Gillette","","1","2023-05-02 16:48:24","2023-05-02 16:48:24");
INSERT INTO brands VALUES("278","Hair-Xpertise","","1","2023-05-02 16:48:24","2023-05-02 16:48:24");
INSERT INTO brands VALUES("279","Hallyu","","1","2023-05-02 16:48:24","2023-05-02 16:48:24");
INSERT INTO brands VALUES("280","Happy Naturals","","1","2023-05-02 16:48:24","2023-05-02 16:48:24");
INSERT INTO brands VALUES("281","Kind Natured","","1","2023-05-02 16:48:24","2023-05-02 16:48:24");
INSERT INTO brands VALUES("282","La Provencale","","1","2023-05-02 16:48:24","2023-05-02 16:48:24");
INSERT INTO brands VALUES("283","Leaders","","1","2023-05-02 16:48:24","2023-05-02 16:48:24");
INSERT INTO brands VALUES("284","LYNX","","1","2023-05-02 16:48:24","2023-05-02 16:48:24");
INSERT INTO brands VALUES("285","Masque Bar","","1","2023-05-02 16:48:24","2023-05-02 16:48:24");
INSERT INTO brands VALUES("286","No! No!","","1","2023-05-02 16:48:24","2023-05-02 16:48:24");
INSERT INTO brands VALUES("287","No7 Beauty","","1","2023-05-02 16:48:24","2023-05-02 16:48:24");
INSERT INTO brands VALUES("288","Naugat London","","1","2023-05-02 16:48:24","2023-05-02 16:48:24");
INSERT INTO brands VALUES("289","Olay","","1","2023-05-02 16:48:24","2023-05-02 16:48:24");
INSERT INTO brands VALUES("290","Possibility","","1","2023-05-02 16:48:24","2023-05-02 16:48:24");
INSERT INTO brands VALUES("291","Pure Paw Paw","","1","2023-05-02 16:48:24","2023-05-02 16:48:24");
INSERT INTO brands VALUES("292","Purity Plus","","1","2023-05-02 16:48:24","2023-05-02 16:48:24");
INSERT INTO brands VALUES("293","Quick Fix Facials","","1","2023-05-02 16:48:24","2023-05-02 16:48:24");
INSERT INTO brands VALUES("294","Revuele Beauty & Care","","1","2023-05-02 16:48:24","2023-05-02 16:48:24");
INSERT INTO brands VALUES("295","Sanex","","1","2023-05-02 16:48:24","2023-05-02 16:48:24");
INSERT INTO brands VALUES("296","Scholl","","1","2023-05-02 16:48:24","2023-05-02 16:48:24");
INSERT INTO brands VALUES("297","Sensai","","1","2023-05-02 16:48:24","2023-05-02 16:48:24");
INSERT INTO brands VALUES("298","Simply","","1","2023-05-02 16:48:24","2023-05-02 16:48:24");
INSERT INTO brands VALUES("299","Skin Academy","","1","2023-05-02 16:48:24","2023-05-02 16:48:24");
INSERT INTO brands VALUES("300","St. Ives","","1","2023-05-02 16:48:24","2023-05-02 16:48:24");
INSERT INTO brands VALUES("301","Sure","","1","2023-05-02 16:48:24","2023-05-02 16:48:24");
INSERT INTO brands VALUES("302","Urban Retreat","","1","2023-05-02 16:48:24","2023-05-02 16:48:24");
INSERT INTO brands VALUES("303","Veet","","1","2023-05-02 16:48:24","2023-05-02 16:48:24");
INSERT INTO brands VALUES("304","Venus","","1","2023-05-02 16:48:24","2023-05-02 16:48:24");
INSERT INTO brands VALUES("305","Victoria's Secret","","1","2023-05-02 16:48:24","2023-05-02 16:48:24");



CREATE TABLE `cash_registers` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `cash_in_hand` double NOT NULL,
  `user_id` int(11) NOT NULL,
  `warehouse_id` int(11) NOT NULL,
  `status` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO cash_registers VALUES("1","100","9","1","0","2020-10-13 00:32:54","2020-10-23 17:27:42");
INSERT INTO cash_registers VALUES("2","50","9","1","1","2020-10-13 08:25:26","2020-10-13 08:25:26");
INSERT INTO cash_registers VALUES("3","200","1","1","0","2020-10-22 00:53:07","2021-06-18 21:52:48");
INSERT INTO cash_registers VALUES("4","100","1","2","0","2020-10-23 18:04:39","2022-03-12 07:18:24");
INSERT INTO cash_registers VALUES("5","1000","1","1","0","2021-06-18 21:53:22","2022-03-12 07:18:31");
INSERT INTO cash_registers VALUES("6","120","1","2","1","2022-03-30 22:29:13","2022-03-30 22:29:13");
INSERT INTO cash_registers VALUES("7","120","1","1","1","2022-11-17 04:10:21","2022-11-17 04:10:21");
INSERT INTO cash_registers VALUES("8","0","41","1","1","2023-03-27 12:17:40","2023-03-27 12:17:40");
INSERT INTO cash_registers VALUES("9","0","43","2","1","2023-04-24 15:57:33","2023-04-24 15:57:33");



CREATE TABLE `categories` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=59 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO categories VALUES("1","Accessories","","","1","2023-03-17 17:28:37","2023-03-17 17:28:37");
INSERT INTO categories VALUES("2","Service","","","1","2023-04-10 13:31:10","2023-04-10 13:31:10");
INSERT INTO categories VALUES("3","Hair Care","","3","1","2023-04-19 14:46:40","2023-05-02 16:16:25");
INSERT INTO categories VALUES("4","Category","","","1","2023-05-02 16:16:25","2023-05-02 16:16:25");
INSERT INTO categories VALUES("5","Advent Calendars","","","1","2023-05-02 16:16:25","2023-05-02 16:16:25");
INSERT INTO categories VALUES("6","Arabic Air Fresheners","","","1","2023-05-02 16:16:25","2023-05-02 16:16:25");
INSERT INTO categories VALUES("7","Arabic Perfumes","","","1","2023-05-02 16:16:25","2023-05-02 16:16:25");
INSERT INTO categories VALUES("8","Back In Stock","","","1","2023-05-02 16:16:25","2023-05-02 16:16:25");
INSERT INTO categories VALUES("9","Body Sprays","","","1","2023-05-02 16:16:25","2023-05-02 16:16:25");
INSERT INTO categories VALUES("10","Coronation Supplies","","","1","2023-05-02 16:16:25","2023-05-02 16:16:25");
INSERT INTO categories VALUES("11","Cosmetic Accessories","","","1","2023-05-02 16:16:25","2023-05-02 16:16:25");
INSERT INTO categories VALUES("12","Cosmetic Bags","","","1","2023-05-02 16:16:25","2023-05-02 16:16:25");
INSERT INTO categories VALUES("13","Cosmetic Brushes","","","1","2023-05-02 16:16:25","2023-05-02 16:16:25");
INSERT INTO categories VALUES("14","Cosmetic Sets","","","1","2023-05-02 16:16:25","2023-05-02 16:16:25");
INSERT INTO categories VALUES("15","Display Stands","","","1","2023-05-02 16:16:25","2023-05-02 16:16:25");
INSERT INTO categories VALUES("16","Electricals","","","1","2023-05-02 16:16:25","2023-05-02 16:16:25");
INSERT INTO categories VALUES("17","Eye Make Up","","","1","2023-05-02 16:16:25","2023-05-02 16:16:25");
INSERT INTO categories VALUES("18","Face Make-up","","","1","2023-05-02 16:16:25","2023-05-02 16:16:25");
INSERT INTO categories VALUES("19","False Eyelashes","","","1","2023-05-02 16:16:25","2023-05-02 16:16:25");
INSERT INTO categories VALUES("20","False Nails","","","1","2023-05-02 16:16:25","2023-05-02 16:16:25");
INSERT INTO categories VALUES("21","Fashion Accessories","","","1","2023-05-02 16:16:25","2023-05-02 16:16:25");
INSERT INTO categories VALUES("22","Fragrances and Sets","","","1","2023-05-02 16:16:25","2023-05-02 16:16:25");
INSERT INTO categories VALUES("23","Gents Fragrances","","","1","2023-05-02 16:16:25","2023-05-02 16:16:25");
INSERT INTO categories VALUES("24","Gift Sets","","","1","2023-05-02 16:16:25","2023-05-02 16:16:25");
INSERT INTO categories VALUES("25","Hair","","","1","2023-05-02 16:16:25","2023-05-02 16:16:25");
INSERT INTO categories VALUES("26","Hair Accessories","","","1","2023-05-02 16:16:25","2023-05-02 16:16:25");
INSERT INTO categories VALUES("27","Hair Brushes","","","1","2023-05-02 16:16:25","2023-05-02 16:16:25");
INSERT INTO categories VALUES("28","Hair Colour","","","1","2023-05-02 16:16:25","2023-05-02 16:16:25");
INSERT INTO categories VALUES("29","Halloween","","","1","2023-05-02 16:16:25","2023-05-02 16:16:25");
INSERT INTO categories VALUES("30","Home Care","","","1","2023-05-02 16:16:25","2023-05-02 16:16:25");
INSERT INTO categories VALUES("31","Infant Care","","","1","2023-05-02 16:16:25","2023-05-02 16:16:25");
INSERT INTO categories VALUES("32","Ladies Fragrances","","","1","2023-05-02 16:16:25","2023-05-02 16:16:25");
INSERT INTO categories VALUES("33","Lip Make-up","","","1","2023-05-02 16:16:25","2023-05-02 16:16:25");
INSERT INTO categories VALUES("34","Male Grooming","","","1","2023-05-02 16:16:25","2023-05-02 16:16:25");
INSERT INTO categories VALUES("35","Mother's Day","","","1","2023-05-02 16:16:25","2023-05-02 16:16:25");
INSERT INTO categories VALUES("36","Nail","","","1","2023-05-02 16:16:25","2023-05-02 16:16:25");
INSERT INTO categories VALUES("37","Nail Accessories","","","1","2023-05-02 16:16:25","2023-05-02 16:16:25");
INSERT INTO categories VALUES("38","Nail Polish","","","1","2023-05-02 16:16:25","2023-05-02 16:16:25");
INSERT INTO categories VALUES("39","Nail Polish Remover","","","1","2023-05-02 16:16:25","2023-05-02 16:16:25");
INSERT INTO categories VALUES("40","New Products","","","1","2023-05-02 16:16:25","2023-05-02 16:16:25");
INSERT INTO categories VALUES("41","Perfume Gift Sets","","","1","2023-05-02 16:16:25","2023-05-02 16:16:25");
INSERT INTO categories VALUES("42","Personal Care","","","1","2023-05-02 16:16:25","2023-05-02 16:16:25");
INSERT INTO categories VALUES("43","Personal Protective Equipment (PPE)","","","1","2023-05-02 16:16:25","2023-05-02 16:16:25");
INSERT INTO categories VALUES("44","Pet Care","","","1","2023-05-02 16:16:25","2023-05-02 16:16:25");
INSERT INTO categories VALUES("45","Self-Tan and Suntan","","","1","2023-05-02 16:16:25","2023-05-02 16:16:25");
INSERT INTO categories VALUES("46","Skin Care","","","1","2023-05-02 16:16:25","2023-05-02 16:16:25");
INSERT INTO categories VALUES("47","SKINCARE","","","1","2023-05-02 16:16:25","2023-05-02 16:16:25");
INSERT INTO categories VALUES("48","Health & Personal Care","","","1","2023-05-02 16:16:25","2023-05-02 16:16:25");
INSERT INTO categories VALUES("49","Grocery","","","1","2023-05-02 16:16:25","2023-05-02 16:16:25");
INSERT INTO categories VALUES("50","Beauty","","","1","2023-05-02 16:16:25","2023-05-02 16:16:25");
INSERT INTO categories VALUES("51","-","","","1","2023-05-02 16:16:25","2023-05-02 16:16:25");
INSERT INTO categories VALUES("52","Baby Products","","","1","2023-05-02 16:16:25","2023-05-02 16:16:25");
INSERT INTO categories VALUES("53","Home & Kitchen","","","1","2023-05-02 16:16:25","2023-05-02 16:16:25");
INSERT INTO categories VALUES("54","Automotive","","","1","2023-05-02 16:16:25","2023-05-02 16:16:25");
INSERT INTO categories VALUES("55","Home & Garden","","","1","2023-05-02 16:16:25","2023-05-02 16:16:25");
INSERT INTO categories VALUES("56","Electronics & Photo","","","1","2023-05-02 16:16:25","2023-05-02 16:16:25");
INSERT INTO categories VALUES("57","Toys & Games","","","1","2023-05-02 16:16:25","2023-05-02 16:16:25");
INSERT INTO categories VALUES("58","Business, Industry & Science","","","1","2023-05-02 16:16:25","2023-05-02 16:16:25");



CREATE TABLE `coupons` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `amount` double NOT NULL,
  `minimum_amount` double DEFAULT NULL,
  `quantity` int(11) NOT NULL,
  `used` int(11) NOT NULL,
  `expired_date` date NOT NULL,
  `user_id` int(11) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;




CREATE TABLE `currencies` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `exchange_rate` double NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO currencies VALUES("1","Pound","GBP","1","2020-10-31 18:29:12","2023-03-22 07:22:40");
INSERT INTO currencies VALUES("2","US Dollar","USD","1.22","2020-10-31 17:22:58","2023-03-22 07:23:04");
INSERT INTO currencies VALUES("3","BDT","bdt ৳","142","2023-03-21 23:24:13","2023-04-24 16:13:59");



CREATE TABLE `customer_groups` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `percentage` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_active` tinyint(1) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO customer_groups VALUES("1","general","0","1","2018-05-12 01:09:36","2019-03-01 23:01:35");
INSERT INTO customer_groups VALUES("2","Garage","0","1","2018-05-12 01:12:14","2023-03-21 18:59:29");
INSERT INTO customer_groups VALUES("3","reseller","0","1","2018-05-12 01:12:26","2023-03-21 18:59:52");
INSERT INTO customer_groups VALUES("6","Wholesale","0","1","2023-03-21 17:36:21","2023-03-21 18:59:59");
INSERT INTO customer_groups VALUES("7","ENGINEER","0","1","2023-03-21 18:58:59","2023-03-21 18:58:59");
INSERT INTO customer_groups VALUES("8","MECHANICS","0","1","2023-03-21 18:59:17","2023-03-21 18:59:17");



CREATE TABLE `customers` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `customer_group_id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `company_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone_number` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tax_no` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `city` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `state` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `postal_code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `country` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `points` double DEFAULT NULL,
  `deposit` double DEFAULT NULL,
  `expense` double DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO customers VALUES("1","1","","Ayon","Largeit","ayat.com@gmail.com","123456789","","Dhaka","Dhaka","","","","6","","","0","2023-03-17 17:05:55","2023-03-21 17:27:31");
INSERT INTO customers VALUES("2","1","","Shamim Ahmed","Bangla Car parts (UK) Ltd.","banglacarparts@gmail.com","07739371171","","Unit 6, 153-155 Ley Street, Ilford IG1 4BL","London","London","IG1 4BL","United Kingdom","64","","","0","2023-03-21 20:35:08","2023-04-10 10:33:38");
INSERT INTO customers VALUES("3","2","","Mr. Johir","multibrand WORKSHOP ltd.","info@mmultibrand-bd.com","+880 1701-224444","","417-418/A, Tejgaon I/A Dhaka","Dhaka","Dhaka","1208","Bangladesh","364729","0","","0","2023-03-21 17:34:02","2023-04-10 10:33:38");
INSERT INTO customers VALUES("4","2","","MOSHIN BABU","SNM Auto Service BD Ltd","snmautobd@gmail.com","+880 1844-060181","","2541 No. Sayeed Nagar, Madani Ave, , Bangladesh","DHAKA","","Dhaka 1229","BANGLADESH","","","","0","2023-03-21 18:50:48","2023-04-10 10:33:38");
INSERT INTO customers VALUES("5","2","","ABDUS SAMAD","Auto Xpress Ltd.(AXL)","autoxpressbd@gmail.com","+880 1713-000592","","Plot-492, Solmaid (Apollo Hospital Link Road), Vatara, Dhaka-1212, Bangladesh","DHAKA","","Dhaka 1229","Bangladesh","","","","0","2023-03-21 18:52:46","2023-04-10 10:33:38");
INSERT INTO customers VALUES("6","1","","ASAD MOYEEN","MOTOR WREK BD","moyeen.asad@gmail.com","+880 1611-540282","","Motorwerks BD. North Mostul. Purbachal highway., Bangladesh","DHAKA","","1229 Dhaka,","BANGLADESH","","","","0","2023-03-21 18:56:04","2023-04-10 10:33:38");
INSERT INTO customers VALUES("7","2","","Autobahn Solutions Ltd","Autobahn Solutions Ltd","Autobahnsolutions@gmail.com","+880 1988-222277","","22 Kuni Pada Road 1208 Tejgaon, Dhaka Division, Bangladesh","DHAKA","","","Bangladesh","","","","0","2023-03-21 18:57:57","2023-04-10 10:33:38");
INSERT INTO customers VALUES("8","1","","Godspeed (BD) Ltd","Godspeed (BD) Ltd","NA@GMAIL.COM","+880 1716-316941","","4th floor, Suite 7 Unicorn Plaza, 40/2 Madani Ave, Dhaka 1212, Bangladesh","DHAKA","","","","","","","0","2023-03-21 19:02:23","2023-04-10 10:33:38");
INSERT INTO customers VALUES("9","1","42","Sujon Ahmed","Largeit","sujonahmed5284@gmail.com","01743405982","","Dhaka","Dhaka","","","","5","","","0","2023-03-22 10:46:55","2023-04-10 10:33:38");
INSERT INTO customers VALUES("10","1","","Arman Baker","","arman.baker@gmail.com","880 1910-222000","","Dhaka","Dhaka","","","Bangladesh","","","","0","2023-03-28 05:13:14","2023-04-10 10:33:38");
INSERT INTO customers VALUES("11","2","","Ashraf Robin","Reload Auto","robin.gbd28@yahoo.com","+880 1310-337555","","Kha 16 Titas Road , Badda","Dhaka","","","Bangladesh","","","","0","2023-03-28 05:20:49","2023-04-10 10:33:38");
INSERT INTO customers VALUES("12","2","","Azad","Rancon Motors Limited","","01712987817","","215 Bir Uttam Mir Shawkat Sarak","Dhaka","","1208","Bangladesh","","","","0","2023-03-28 11:44:32","2023-04-10 10:33:43");
INSERT INTO customers VALUES("13","1","","Nazrul Islam","ANK All out Ltd","","01835041567","","2/16, Block-B, Level-6, Flat-5c","Lalmatia, Mohammadpur, Dhaka","Lalmatia, Mohammadpur","1207","Bangladesh","24","2000","","1","2023-04-10 10:34:50","2023-04-17 12:16:13");
INSERT INTO customers VALUES("14","1","","Nexus Corporation","Nexus Corporation","","01727080029","","14 kakrail , First Floor","Dhaka, Bangladesh","","1000","Bangladesh","5","","","1","2023-04-19 14:26:02","2023-04-19 14:34:29");
INSERT INTO customers VALUES("15","1","44","Cosmetics world","Cosmetics world","rizonlami@gmail.com","01711057659","","Chandpur kalibari","chandpur","","","Bangladesh","","","","1","2023-05-05 09:37:32","2023-05-05 09:37:32");



CREATE TABLE `deliveries` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `reference_no` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sale_id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `address` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `delivered_by` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `recieved_by` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `file` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `note` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;




CREATE TABLE `departments` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO departments VALUES("1","Sale","1","2018-12-26 22:16:47","2018-12-27 03:40:23");
INSERT INTO departments VALUES("2","Marketing","1","2018-12-27 03:28:47","2023-03-17 17:07:23");



CREATE TABLE `deposits` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `amount` double NOT NULL,
  `customer_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `note` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO deposits VALUES("3","2000","13","1","","2023-04-17 12:04:47","2023-04-17 12:04:47");



CREATE TABLE `discount_plan_customers` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `discount_plan_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO discount_plan_customers VALUES("3","1","2","2023-03-21 23:11:32","2023-03-21 23:11:32");



CREATE TABLE `discount_plan_discounts` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `discount_id` int(11) NOT NULL,
  `discount_plan_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO discount_plan_discounts VALUES("1","1","1","2022-02-03 06:02:17","2022-02-03 06:02:17");



CREATE TABLE `discount_plans` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO discount_plans VALUES("1","VIP plan","1","2022-02-03 05:58:12","2022-02-03 05:58:12");



CREATE TABLE `discounts` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `applicable_for` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_list` longtext COLLATE utf8mb4_unicode_ci,
  `valid_from` date NOT NULL,
  `valid_till` date NOT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` double NOT NULL,
  `minimum_qty` double NOT NULL,
  `maximum_qty` double NOT NULL,
  `days` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO discounts VALUES("1","10% discount","Specific","5,3","2022-02-03","2022-12-31","percentage","10","2","3","Mon,Tue,Wed,Thu,Fri,Sat,Sun","1","2022-02-03 06:02:17","2022-04-23 05:58:26");



CREATE TABLE `dso_alerts` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `product_info` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `number_of_products` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO dso_alerts VALUES("1","[{"name":"Baby doll","code":"31261512"}]","1","2022-05-27 22:27:46","2022-05-27 22:27:46");



CREATE TABLE `employees` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone_number` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `department_id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `city` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `country` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO employees VALUES("1","Ifti","ifti@gmail.com","123456789","2","12","johngmailcom.jpg","Dhaka","Dhaka","Bangladesh","1","2018-12-29 17:48:37","2023-03-17 17:08:34");
INSERT INTO employees VALUES("3","Sujon Ahmed","sujonahmed@gmail.com","123456789","1","","sujonahmedgmailcom.jpg","Dhaka","Dhaka","Bangladesh","1","2018-12-30 15:20:51","2023-03-17 17:09:49");



CREATE TABLE `expense_categories` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO expense_categories VALUES("1","71135002","Foods","1","2023-03-20 17:22:46","2023-03-20 17:22:46");
INSERT INTO expense_categories VALUES("2","stationary","stationary","1","2023-03-21 17:37:32","2023-03-21 17:37:32");
INSERT INTO expense_categories VALUES("3","Rent","Tiss","1","2023-03-21 17:37:46","2023-03-21 17:37:46");
INSERT INTO expense_categories VALUES("4","E1 cargo","Moshin vai","1","2023-03-21 17:38:59","2023-03-21 17:38:59");
INSERT INTO expense_categories VALUES("5","All time cargo","Mithu vai","1","2023-03-21 17:39:56","2023-03-21 17:39:56");
INSERT INTO expense_categories VALUES("6","hospitalty","Abdulah vai","1","2023-03-21 17:40:26","2023-03-21 17:40:26");
INSERT INTO expense_categories VALUES("7","capital on tap","Credit card bill","1","2023-03-21 17:41:27","2023-03-21 17:41:27");
INSERT INTO expense_categories VALUES("8","Telephone bill","Xln","1","2023-03-21 17:41:57","2023-03-21 17:42:07");
INSERT INTO expense_categories VALUES("9","Marketing","facebook","1","2023-03-21 17:42:28","2023-03-21 17:42:28");
INSERT INTO expense_categories VALUES("10","printer ink","lexmark","1","2023-03-21 17:43:01","2023-03-21 17:43:01");
INSERT INTO expense_categories VALUES("11","packaging","packaging","1","2023-03-21 17:43:23","2023-03-21 17:43:23");
INSERT INTO expense_categories VALUES("12","bank charges","expenses","1","2023-03-21 17:44:03","2023-03-21 17:44:03");
INSERT INTO expense_categories VALUES("13","Lunch","outside","1","2023-03-21 17:45:13","2023-03-21 17:45:32");
INSERT INTO expense_categories VALUES("14","Furniture","Furniture","1","2023-03-21 17:46:08","2023-03-21 17:46:08");
INSERT INTO expense_categories VALUES("15","Fiver","Outsourcing","1","2023-03-21 17:46:24","2023-03-21 17:46:24");
INSERT INTO expense_categories VALUES("16","It","IT","1","2023-03-21 17:46:35","2023-03-21 17:46:35");
INSERT INTO expense_categories VALUES("17","C&F BILL","C&F BILL","1","2023-03-21 19:04:34","2023-03-21 19:04:34");
INSERT INTO expense_categories VALUES("18","37230316","PRINTING","1","2023-03-27 16:20:43","2023-03-27 16:20:43");
INSERT INTO expense_categories VALUES("19","98702195","EQUIPMENT","1","2023-03-27 16:20:59","2023-03-27 16:20:59");
INSERT INTO expense_categories VALUES("20","62518249","OTHERS","1","2023-03-27 16:23:47","2023-03-27 16:23:47");



CREATE TABLE `expenses` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `reference_no` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `expense_category_id` int(11) NOT NULL,
  `warehouse_id` int(11) NOT NULL,
  `account_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `cash_register_id` int(11) DEFAULT NULL,
  `amount` double NOT NULL,
  `note` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;




CREATE TABLE `failed_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;




CREATE TABLE `general_settings` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `site_title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `site_logo` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_rtl` tinyint(1) DEFAULT NULL,
  `currency` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `staff_access` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `date_format` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `developed_by` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `invoice_format` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `state` int(11) DEFAULT NULL,
  `theme` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `currency_position` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO general_settings VALUES("1","AMBS Global UK Ltd.","20230406075330.jpeg","0","1","own","d/m/Y","Large iT Solution","standard","1","default.css","2018-07-05 23:13:11","2023-04-10 13:27:29","prefix");



CREATE TABLE `gift_card_recharges` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `gift_card_id` int(11) NOT NULL,
  `amount` double NOT NULL,
  `user_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;




CREATE TABLE `gift_cards` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `card_no` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `amount` double NOT NULL,
  `expense` double NOT NULL,
  `customer_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `expired_date` date DEFAULT NULL,
  `created_by` int(11) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;




CREATE TABLE `holidays` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `from_date` date NOT NULL,
  `to_date` date NOT NULL,
  `note` text COLLATE utf8mb4_unicode_ci,
  `is_approved` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;




CREATE TABLE `hrm_settings` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `checkin` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `checkout` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO hrm_settings VALUES("1","10:00am","6:00pm","2019-01-01 19:20:08","2019-01-01 21:20:53");



CREATE TABLE `languages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO languages VALUES("1","en","2018-07-07 15:59:17","2019-12-24 10:34:20");



CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=162 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO migrations VALUES("1","2014_10_12_000000_create_users_table","1");
INSERT INTO migrations VALUES("2","2014_10_12_100000_create_password_resets_table","1");
INSERT INTO migrations VALUES("3","2018_02_17_060412_create_categories_table","1");
INSERT INTO migrations VALUES("4","2018_02_20_035727_create_brands_table","1");
INSERT INTO migrations VALUES("5","2018_02_25_100635_create_suppliers_table","1");
INSERT INTO migrations VALUES("6","2018_02_27_101619_create_warehouse_table","1");
INSERT INTO migrations VALUES("7","2018_03_03_040448_create_units_table","1");
INSERT INTO migrations VALUES("8","2018_03_04_041317_create_taxes_table","1");
INSERT INTO migrations VALUES("9","2018_03_10_061915_create_customer_groups_table","1");
INSERT INTO migrations VALUES("10","2018_03_10_090534_create_customers_table","1");
INSERT INTO migrations VALUES("11","2018_03_11_095547_create_billers_table","1");
INSERT INTO migrations VALUES("12","2018_04_05_054401_create_products_table","1");
INSERT INTO migrations VALUES("13","2018_04_06_133606_create_purchases_table","1");
INSERT INTO migrations VALUES("14","2018_04_06_154600_create_product_purchases_table","1");
INSERT INTO migrations VALUES("15","2018_04_06_154915_create_product_warhouse_table","1");
INSERT INTO migrations VALUES("16","2018_04_10_085927_create_sales_table","1");
INSERT INTO migrations VALUES("17","2018_04_10_090133_create_product_sales_table","1");
INSERT INTO migrations VALUES("18","2018_04_10_090254_create_payments_table","1");
INSERT INTO migrations VALUES("19","2018_04_10_090341_create_payment_with_cheque_table","1");
INSERT INTO migrations VALUES("20","2018_04_10_090509_create_payment_with_credit_card_table","1");
INSERT INTO migrations VALUES("21","2018_04_13_121436_create_quotation_table","1");
INSERT INTO migrations VALUES("22","2018_04_13_122324_create_product_quotation_table","1");
INSERT INTO migrations VALUES("23","2018_04_14_121802_create_transfers_table","1");
INSERT INTO migrations VALUES("24","2018_04_14_121913_create_product_transfer_table","1");
INSERT INTO migrations VALUES("25","2018_05_13_082847_add_payment_id_and_change_sale_id_to_payments_table","2");
INSERT INTO migrations VALUES("26","2018_05_13_090906_change_customer_id_to_payment_with_credit_card_table","3");
INSERT INTO migrations VALUES("27","2018_05_20_054532_create_adjustments_table","4");
INSERT INTO migrations VALUES("28","2018_05_20_054859_create_product_adjustments_table","4");
INSERT INTO migrations VALUES("29","2018_05_21_163419_create_returns_table","5");
INSERT INTO migrations VALUES("30","2018_05_21_163443_create_product_returns_table","5");
INSERT INTO migrations VALUES("31","2018_06_02_050905_create_roles_table","6");
INSERT INTO migrations VALUES("32","2018_06_02_073430_add_columns_to_users_table","7");
INSERT INTO migrations VALUES("33","2018_06_03_053738_create_permission_tables","8");
INSERT INTO migrations VALUES("36","2018_06_21_063736_create_pos_setting_table","9");
INSERT INTO migrations VALUES("37","2018_06_21_094155_add_user_id_to_sales_table","10");
INSERT INTO migrations VALUES("38","2018_06_21_101529_add_user_id_to_purchases_table","11");
INSERT INTO migrations VALUES("39","2018_06_21_103512_add_user_id_to_transfers_table","12");
INSERT INTO migrations VALUES("40","2018_06_23_061058_add_user_id_to_quotations_table","13");
INSERT INTO migrations VALUES("41","2018_06_23_082427_add_is_deleted_to_users_table","14");
INSERT INTO migrations VALUES("42","2018_06_25_043308_change_email_to_users_table","15");
INSERT INTO migrations VALUES("43","2018_07_06_115449_create_general_settings_table","16");
INSERT INTO migrations VALUES("44","2018_07_08_043944_create_languages_table","17");
INSERT INTO migrations VALUES("45","2018_07_11_102144_add_user_id_to_returns_table","18");
INSERT INTO migrations VALUES("46","2018_07_11_102334_add_user_id_to_payments_table","18");
INSERT INTO migrations VALUES("47","2018_07_22_130541_add_digital_to_products_table","19");
INSERT INTO migrations VALUES("49","2018_07_24_154250_create_deliveries_table","20");
INSERT INTO migrations VALUES("50","2018_08_16_053336_create_expense_categories_table","21");
INSERT INTO migrations VALUES("51","2018_08_17_115415_create_expenses_table","22");
INSERT INTO migrations VALUES("55","2018_08_18_050418_create_gift_cards_table","23");
INSERT INTO migrations VALUES("56","2018_08_19_063119_create_payment_with_gift_card_table","24");
INSERT INTO migrations VALUES("57","2018_08_25_042333_create_gift_card_recharges_table","25");
INSERT INTO migrations VALUES("58","2018_08_25_101354_add_deposit_expense_to_customers_table","26");
INSERT INTO migrations VALUES("59","2018_08_26_043801_create_deposits_table","27");
INSERT INTO migrations VALUES("60","2018_09_02_044042_add_keybord_active_to_pos_setting_table","28");
INSERT INTO migrations VALUES("61","2018_09_09_092713_create_payment_with_paypal_table","29");
INSERT INTO migrations VALUES("62","2018_09_10_051254_add_currency_to_general_settings_table","30");
INSERT INTO migrations VALUES("63","2018_10_22_084118_add_biller_and_store_id_to_users_table","31");
INSERT INTO migrations VALUES("65","2018_10_26_034927_create_coupons_table","32");
INSERT INTO migrations VALUES("66","2018_10_27_090857_add_coupon_to_sales_table","33");
INSERT INTO migrations VALUES("67","2018_11_07_070155_add_currency_position_to_general_settings_table","34");
INSERT INTO migrations VALUES("68","2018_11_19_094650_add_combo_to_products_table","35");
INSERT INTO migrations VALUES("69","2018_12_09_043712_create_accounts_table","36");
INSERT INTO migrations VALUES("70","2018_12_17_112253_add_is_default_to_accounts_table","37");
INSERT INTO migrations VALUES("71","2018_12_19_103941_add_account_id_to_payments_table","38");
INSERT INTO migrations VALUES("72","2018_12_20_065900_add_account_id_to_expenses_table","39");
INSERT INTO migrations VALUES("73","2018_12_20_082753_add_account_id_to_returns_table","40");
INSERT INTO migrations VALUES("74","2018_12_26_064330_create_return_purchases_table","41");
INSERT INTO migrations VALUES("75","2018_12_26_144210_create_purchase_product_return_table","42");
INSERT INTO migrations VALUES("76","2018_12_26_144708_create_purchase_product_return_table","43");
INSERT INTO migrations VALUES("77","2018_12_27_110018_create_departments_table","44");
INSERT INTO migrations VALUES("78","2018_12_30_054844_create_employees_table","45");
INSERT INTO migrations VALUES("79","2018_12_31_125210_create_payrolls_table","46");
INSERT INTO migrations VALUES("80","2018_12_31_150446_add_department_id_to_employees_table","47");
INSERT INTO migrations VALUES("81","2019_01_01_062708_add_user_id_to_expenses_table","48");
INSERT INTO migrations VALUES("82","2019_01_02_075644_create_hrm_settings_table","49");
INSERT INTO migrations VALUES("83","2019_01_02_090334_create_attendances_table","50");
INSERT INTO migrations VALUES("84","2019_01_27_160956_add_three_columns_to_general_settings_table","51");
INSERT INTO migrations VALUES("85","2019_02_15_183303_create_stock_counts_table","52");
INSERT INTO migrations VALUES("86","2019_02_17_101604_add_is_adjusted_to_stock_counts_table","53");
INSERT INTO migrations VALUES("87","2019_04_13_101707_add_tax_no_to_customers_table","54");
INSERT INTO migrations VALUES("89","2019_10_14_111455_create_holidays_table","55");
INSERT INTO migrations VALUES("90","2019_11_13_145619_add_is_variant_to_products_table","56");
INSERT INTO migrations VALUES("91","2019_11_13_150206_create_product_variants_table","57");
INSERT INTO migrations VALUES("92","2019_11_13_153828_create_variants_table","57");
INSERT INTO migrations VALUES("93","2019_11_25_134041_add_qty_to_product_variants_table","58");
INSERT INTO migrations VALUES("94","2019_11_25_134922_add_variant_id_to_product_purchases_table","58");
INSERT INTO migrations VALUES("95","2019_11_25_145341_add_variant_id_to_product_warehouse_table","58");
INSERT INTO migrations VALUES("96","2019_11_29_182201_add_variant_id_to_product_sales_table","59");
INSERT INTO migrations VALUES("97","2019_12_04_121311_add_variant_id_to_product_quotation_table","60");
INSERT INTO migrations VALUES("98","2019_12_05_123802_add_variant_id_to_product_transfer_table","61");
INSERT INTO migrations VALUES("100","2019_12_08_114954_add_variant_id_to_product_returns_table","62");
INSERT INTO migrations VALUES("101","2019_12_08_203146_add_variant_id_to_purchase_product_return_table","63");
INSERT INTO migrations VALUES("102","2020_02_28_103340_create_money_transfers_table","64");
INSERT INTO migrations VALUES("103","2020_07_01_193151_add_image_to_categories_table","65");
INSERT INTO migrations VALUES("105","2020_09_26_130426_add_user_id_to_deliveries_table","66");
INSERT INTO migrations VALUES("107","2020_10_11_125457_create_cash_registers_table","67");
INSERT INTO migrations VALUES("108","2020_10_13_155019_add_cash_register_id_to_sales_table","68");
INSERT INTO migrations VALUES("109","2020_10_13_172624_add_cash_register_id_to_returns_table","69");
INSERT INTO migrations VALUES("110","2020_10_17_212338_add_cash_register_id_to_payments_table","70");
INSERT INTO migrations VALUES("111","2020_10_18_124200_add_cash_register_id_to_expenses_table","71");
INSERT INTO migrations VALUES("112","2020_10_21_121632_add_developed_by_to_general_settings_table","72");
INSERT INTO migrations VALUES("113","2019_08_19_000000_create_failed_jobs_table","73");
INSERT INTO migrations VALUES("114","2020_10_30_135557_create_notifications_table","73");
INSERT INTO migrations VALUES("115","2020_11_01_044954_create_currencies_table","74");
INSERT INTO migrations VALUES("116","2020_11_01_140736_add_price_to_product_warehouse_table","75");
INSERT INTO migrations VALUES("117","2020_11_02_050633_add_is_diff_price_to_products_table","76");
INSERT INTO migrations VALUES("118","2020_11_09_055222_add_user_id_to_customers_table","77");
INSERT INTO migrations VALUES("119","2020_11_17_054806_add_invoice_format_to_general_settings_table","78");
INSERT INTO migrations VALUES("120","2021_02_10_074859_add_variant_id_to_product_adjustments_table","79");
INSERT INTO migrations VALUES("121","2021_03_07_093606_create_product_batches_table","80");
INSERT INTO migrations VALUES("122","2021_03_07_093759_add_product_batch_id_to_product_warehouse_table","80");
INSERT INTO migrations VALUES("123","2021_03_07_093900_add_product_batch_id_to_product_purchases_table","80");
INSERT INTO migrations VALUES("124","2021_03_11_132603_add_product_batch_id_to_product_sales_table","81");
INSERT INTO migrations VALUES("127","2021_03_25_125421_add_is_batch_to_products_table","82");
INSERT INTO migrations VALUES("128","2021_05_19_120127_add_product_batch_id_to_product_returns_table","82");
INSERT INTO migrations VALUES("130","2021_05_22_105611_add_product_batch_id_to_purchase_product_return_table","83");
INSERT INTO migrations VALUES("131","2021_05_23_124848_add_product_batch_id_to_product_transfer_table","84");
INSERT INTO migrations VALUES("132","2021_05_26_153106_add_product_batch_id_to_product_quotation_table","85");
INSERT INTO migrations VALUES("133","2021_06_08_213007_create_reward_point_settings_table","86");
INSERT INTO migrations VALUES("134","2021_06_16_104155_add_points_to_customers_table","87");
INSERT INTO migrations VALUES("135","2021_06_17_101057_add_used_points_to_payments_table","88");
INSERT INTO migrations VALUES("136","2021_07_06_132716_add_variant_list_to_products_table","89");
INSERT INTO migrations VALUES("137","2021_09_27_161141_add_is_imei_to_products_table","90");
INSERT INTO migrations VALUES("138","2021_09_28_170052_add_imei_number_to_product_warehouse_table","91");
INSERT INTO migrations VALUES("139","2021_09_28_170126_add_imei_number_to_product_purchases_table","91");
INSERT INTO migrations VALUES("140","2021_10_03_170652_add_imei_number_to_product_sales_table","92");
INSERT INTO migrations VALUES("141","2021_10_10_145214_add_imei_number_to_product_returns_table","93");
INSERT INTO migrations VALUES("142","2021_10_11_104504_add_imei_number_to_product_transfer_table","94");
INSERT INTO migrations VALUES("143","2021_10_12_160107_add_imei_number_to_purchase_product_return_table","95");
INSERT INTO migrations VALUES("144","2021_10_12_205146_add_is_rtl_to_general_settings_table","96");
INSERT INTO migrations VALUES("145","2021_10_23_142451_add_is_approve_to_payments_table","97");
INSERT INTO migrations VALUES("146","2022_01_13_191242_create_discount_plans_table","97");
INSERT INTO migrations VALUES("147","2022_01_14_174318_create_discount_plan_customers_table","97");
INSERT INTO migrations VALUES("148","2022_01_14_202439_create_discounts_table","98");
INSERT INTO migrations VALUES("149","2022_01_16_153506_create_discount_plan_discounts_table","98");
INSERT INTO migrations VALUES("150","2022_02_05_174210_add_order_discount_type_and_value_to_sales_table","99");
INSERT INTO migrations VALUES("154","2022_05_26_195506_add_daily_sale_objective_to_products_table","100");
INSERT INTO migrations VALUES("155","2022_05_28_104209_create_dso_alerts_table","101");
INSERT INTO migrations VALUES("156","2022_06_01_112100_add_is_embeded_to_products_table","102");
INSERT INTO migrations VALUES("157","2022_06_14_130505_add_sale_id_to_returns_table","103");
INSERT INTO migrations VALUES("159","2022_07_19_115504_add_variant_data_to_products_table","104");
INSERT INTO migrations VALUES("160","2022_07_25_194300_add_additional_cost_to_product_variants_table","104");
INSERT INTO migrations VALUES("161","2022_09_04_195610_add_purchase_id_to_return_purchases_table","105");



CREATE TABLE `money_transfers` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `reference_no` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `from_account_id` int(11) NOT NULL,
  `to_account_id` int(11) NOT NULL,
  `amount` double NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO money_transfers VALUES("3","mtr-20230327-113923","9","5","1000","2023-03-27 11:39:23","2023-03-27 11:39:23");



CREATE TABLE `notifications` (
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `notifiable_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `notifiable_id` bigint(20) unsigned NOT NULL,
  `data` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `read_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `notifications_notifiable_type_notifiable_id_index` (`notifiable_type`,`notifiable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO notifications VALUES("d0623880-4199-459c-af55-3bc1464cbe71","App\Notifications\SendNotification","App\User","9","{"sender_id":"1","receiver_id":"9","document_name":"20220523012859.jpg","message":"hjhjhh"}","2022-05-23 02:50:47","2022-05-23 00:29:00","2022-05-23 02:50:47");
INSERT INTO notifications VALUES("ea3e6ccc-a25a-44b7-8e43-b0ab09204ee6","App\Notifications\SendNotification","App\User","9","{"sender_id":"1","receiver_id":"9","document_name":null,"message":"hello"}","2022-05-23 03:24:31","2022-05-23 03:24:06","2022-05-23 03:24:31");



CREATE TABLE `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO password_resets VALUES("sujonahmed5284@gmail.com","$2y$10$ozxSSne7ZxWcT32NnJpvmuarZfEAQbEgN2z5p0oqTyOq1Z6R4yvve","2023-03-22 10:47:22");



CREATE TABLE `payment_with_cheque` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `payment_id` int(11) NOT NULL,
  `cheque_no` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;




CREATE TABLE `payment_with_credit_card` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `payment_id` int(11) NOT NULL,
  `customer_id` int(11) DEFAULT NULL,
  `customer_stripe_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `charge_id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;




CREATE TABLE `payment_with_gift_card` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `payment_id` int(11) NOT NULL,
  `gift_card_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;




CREATE TABLE `payment_with_paypal` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `payment_id` int(11) NOT NULL,
  `transaction_id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;




CREATE TABLE `payments` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `payment_reference` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` int(11) NOT NULL,
  `purchase_id` int(11) DEFAULT NULL,
  `sale_id` int(11) DEFAULT NULL,
  `cash_register_id` int(11) DEFAULT NULL,
  `account_id` int(11) NOT NULL,
  `amount` double NOT NULL,
  `used_points` double DEFAULT NULL,
  `change` double NOT NULL,
  `paying_method` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payment_note` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=140 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO payments VALUES("139","spr-20230412-114313","1","","75","7","5","1925.23","","0","Cash","","2023-04-12 11:43:13","2023-04-12 11:43:13");



CREATE TABLE `payrolls` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `reference_no` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `employee_id` int(11) NOT NULL,
  `account_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `amount` double NOT NULL,
  `paying_method` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `note` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;




CREATE TABLE `permissions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=126 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO permissions VALUES("4","products-edit","web","2018-06-02 18:00:09","2018-06-02 18:00:09");
INSERT INTO permissions VALUES("5","products-delete","web","2018-06-03 15:54:22","2018-06-03 15:54:22");
INSERT INTO permissions VALUES("6","products-add","web","2018-06-03 17:34:14","2018-06-03 17:34:14");
INSERT INTO permissions VALUES("7","products-index","web","2018-06-03 20:34:27","2018-06-03 20:34:27");
INSERT INTO permissions VALUES("8","purchases-index","web","2018-06-04 01:03:19","2018-06-04 01:03:19");
INSERT INTO permissions VALUES("9","purchases-add","web","2018-06-04 01:12:25","2018-06-04 01:12:25");
INSERT INTO permissions VALUES("10","purchases-edit","web","2018-06-04 02:47:36","2018-06-04 02:47:36");
INSERT INTO permissions VALUES("11","purchases-delete","web","2018-06-04 02:47:36","2018-06-04 02:47:36");
INSERT INTO permissions VALUES("12","sales-index","web","2018-06-04 03:49:08","2018-06-04 03:49:08");
INSERT INTO permissions VALUES("13","sales-add","web","2018-06-04 03:49:52","2018-06-04 03:49:52");
INSERT INTO permissions VALUES("14","sales-edit","web","2018-06-04 03:49:52","2018-06-04 03:49:52");
INSERT INTO permissions VALUES("15","sales-delete","web","2018-06-04 03:49:53","2018-06-04 03:49:53");
INSERT INTO permissions VALUES("16","quotes-index","web","2018-06-04 15:05:10","2018-06-04 15:05:10");
INSERT INTO permissions VALUES("17","quotes-add","web","2018-06-04 15:05:10","2018-06-04 15:05:10");
INSERT INTO permissions VALUES("18","quotes-edit","web","2018-06-04 15:05:10","2018-06-04 15:05:10");
INSERT INTO permissions VALUES("19","quotes-delete","web","2018-06-04 15:05:10","2018-06-04 15:05:10");
INSERT INTO permissions VALUES("20","transfers-index","web","2018-06-04 15:30:03","2018-06-04 15:30:03");
INSERT INTO permissions VALUES("21","transfers-add","web","2018-06-04 15:30:03","2018-06-04 15:30:03");
INSERT INTO permissions VALUES("22","transfers-edit","web","2018-06-04 15:30:03","2018-06-04 15:30:03");
INSERT INTO permissions VALUES("23","transfers-delete","web","2018-06-04 15:30:03","2018-06-04 15:30:03");
INSERT INTO permissions VALUES("24","returns-index","web","2018-06-04 15:50:24","2018-06-04 15:50:24");
INSERT INTO permissions VALUES("25","returns-add","web","2018-06-04 15:50:24","2018-06-04 15:50:24");
INSERT INTO permissions VALUES("26","returns-edit","web","2018-06-04 15:50:25","2018-06-04 15:50:25");
INSERT INTO permissions VALUES("27","returns-delete","web","2018-06-04 15:50:25","2018-06-04 15:50:25");
INSERT INTO permissions VALUES("28","customers-index","web","2018-06-04 16:15:54","2018-06-04 16:15:54");
INSERT INTO permissions VALUES("29","customers-add","web","2018-06-04 16:15:55","2018-06-04 16:15:55");
INSERT INTO permissions VALUES("30","customers-edit","web","2018-06-04 16:15:55","2018-06-04 16:15:55");
INSERT INTO permissions VALUES("31","customers-delete","web","2018-06-04 16:15:55","2018-06-04 16:15:55");
INSERT INTO permissions VALUES("32","suppliers-index","web","2018-06-04 16:40:12","2018-06-04 16:40:12");
INSERT INTO permissions VALUES("33","suppliers-add","web","2018-06-04 16:40:12","2018-06-04 16:40:12");
INSERT INTO permissions VALUES("34","suppliers-edit","web","2018-06-04 16:40:12","2018-06-04 16:40:12");
INSERT INTO permissions VALUES("35","suppliers-delete","web","2018-06-04 16:40:12","2018-06-04 16:40:12");
INSERT INTO permissions VALUES("36","product-report","web","2018-06-24 16:05:33","2018-06-24 16:05:33");
INSERT INTO permissions VALUES("37","purchase-report","web","2018-06-24 16:24:56","2018-06-24 16:24:56");
INSERT INTO permissions VALUES("38","sale-report","web","2018-06-24 16:33:13","2018-06-24 16:33:13");
INSERT INTO permissions VALUES("39","customer-report","web","2018-06-24 16:36:51","2018-06-24 16:36:51");
INSERT INTO permissions VALUES("40","due-report","web","2018-06-24 16:39:52","2018-06-24 16:39:52");
INSERT INTO permissions VALUES("41","users-index","web","2018-06-24 17:00:10","2018-06-24 17:00:10");
INSERT INTO permissions VALUES("42","users-add","web","2018-06-24 17:00:10","2018-06-24 17:00:10");
INSERT INTO permissions VALUES("43","users-edit","web","2018-06-24 17:01:30","2018-06-24 17:01:30");
INSERT INTO permissions VALUES("44","users-delete","web","2018-06-24 17:01:30","2018-06-24 17:01:30");
INSERT INTO permissions VALUES("45","profit-loss","web","2018-07-14 14:50:05","2018-07-14 14:50:05");
INSERT INTO permissions VALUES("46","best-seller","web","2018-07-14 15:01:38","2018-07-14 15:01:38");
INSERT INTO permissions VALUES("47","daily-sale","web","2018-07-14 15:24:21","2018-07-14 15:24:21");
INSERT INTO permissions VALUES("48","monthly-sale","web","2018-07-14 15:30:41","2018-07-14 15:30:41");
INSERT INTO permissions VALUES("49","daily-purchase","web","2018-07-14 15:36:46","2018-07-14 15:36:46");
INSERT INTO permissions VALUES("50","monthly-purchase","web","2018-07-14 15:48:17","2018-07-14 15:48:17");
INSERT INTO permissions VALUES("51","payment-report","web","2018-07-14 16:10:41","2018-07-14 16:10:41");
INSERT INTO permissions VALUES("52","warehouse-stock-report","web","2018-07-14 16:16:55","2018-07-14 16:16:55");
INSERT INTO permissions VALUES("53","product-qty-alert","web","2018-07-14 16:33:21","2018-07-14 16:33:21");
INSERT INTO permissions VALUES("54","supplier-report","web","2018-07-29 20:00:01","2018-07-29 20:00:01");
INSERT INTO permissions VALUES("55","expenses-index","web","2018-09-04 18:07:10","2018-09-04 18:07:10");
INSERT INTO permissions VALUES("56","expenses-add","web","2018-09-04 18:07:10","2018-09-04 18:07:10");
INSERT INTO permissions VALUES("57","expenses-edit","web","2018-09-04 18:07:10","2018-09-04 18:07:10");
INSERT INTO permissions VALUES("58","expenses-delete","web","2018-09-04 18:07:11","2018-09-04 18:07:11");
INSERT INTO permissions VALUES("59","general_setting","web","2018-10-19 16:10:04","2018-10-19 16:10:04");
INSERT INTO permissions VALUES("60","mail_setting","web","2018-10-19 16:10:04","2018-10-19 16:10:04");
INSERT INTO permissions VALUES("61","pos_setting","web","2018-10-19 16:10:04","2018-10-19 16:10:04");
INSERT INTO permissions VALUES("62","hrm_setting","web","2019-01-02 03:30:23","2019-01-02 03:30:23");
INSERT INTO permissions VALUES("63","purchase-return-index","web","2019-01-02 14:45:14","2019-01-02 14:45:14");
INSERT INTO permissions VALUES("64","purchase-return-add","web","2019-01-02 14:45:14","2019-01-02 14:45:14");
INSERT INTO permissions VALUES("65","purchase-return-edit","web","2019-01-02 14:45:14","2019-01-02 14:45:14");
INSERT INTO permissions VALUES("66","purchase-return-delete","web","2019-01-02 14:45:14","2019-01-02 14:45:14");
INSERT INTO permissions VALUES("67","account-index","web","2019-01-02 15:06:13","2019-01-02 15:06:13");
INSERT INTO permissions VALUES("68","balance-sheet","web","2019-01-02 15:06:14","2019-01-02 15:06:14");
INSERT INTO permissions VALUES("69","account-statement","web","2019-01-02 15:06:14","2019-01-02 15:06:14");
INSERT INTO permissions VALUES("70","department","web","2019-01-02 15:30:01","2019-01-02 15:30:01");
INSERT INTO permissions VALUES("71","attendance","web","2019-01-02 15:30:01","2019-01-02 15:30:01");
INSERT INTO permissions VALUES("72","payroll","web","2019-01-02 15:30:01","2019-01-02 15:30:01");
INSERT INTO permissions VALUES("73","employees-index","web","2019-01-02 15:52:19","2019-01-02 15:52:19");
INSERT INTO permissions VALUES("74","employees-add","web","2019-01-02 15:52:19","2019-01-02 15:52:19");
INSERT INTO permissions VALUES("75","employees-edit","web","2019-01-02 15:52:19","2019-01-02 15:52:19");
INSERT INTO permissions VALUES("76","employees-delete","web","2019-01-02 15:52:19","2019-01-02 15:52:19");
INSERT INTO permissions VALUES("77","user-report","web","2019-01-15 23:48:18","2019-01-15 23:48:18");
INSERT INTO permissions VALUES("78","stock_count","web","2019-02-17 03:32:01","2019-02-17 03:32:01");
INSERT INTO permissions VALUES("79","adjustment","web","2019-02-17 03:32:02","2019-02-17 03:32:02");
INSERT INTO permissions VALUES("80","sms_setting","web","2019-02-21 22:18:03","2019-02-21 22:18:03");
INSERT INTO permissions VALUES("81","create_sms","web","2019-02-21 22:18:03","2019-02-21 22:18:03");
INSERT INTO permissions VALUES("82","print_barcode","web","2019-03-06 22:02:19","2019-03-06 22:02:19");
INSERT INTO permissions VALUES("83","empty_database","web","2019-03-06 22:02:19","2019-03-06 22:02:19");
INSERT INTO permissions VALUES("84","customer_group","web","2019-03-06 22:37:15","2019-03-06 22:37:15");
INSERT INTO permissions VALUES("85","unit","web","2019-03-06 22:37:15","2019-03-06 22:37:15");
INSERT INTO permissions VALUES("86","tax","web","2019-03-06 22:37:15","2019-03-06 22:37:15");
INSERT INTO permissions VALUES("87","gift_card","web","2019-03-06 23:29:38","2019-03-06 23:29:38");
INSERT INTO permissions VALUES("88","coupon","web","2019-03-06 23:29:38","2019-03-06 23:29:38");
INSERT INTO permissions VALUES("89","holiday","web","2019-10-19 01:57:15","2019-10-19 01:57:15");
INSERT INTO permissions VALUES("90","warehouse-report","web","2019-10-21 23:00:23","2019-10-21 23:00:23");
INSERT INTO permissions VALUES("91","warehouse","web","2020-02-25 23:47:32","2020-02-25 23:47:32");
INSERT INTO permissions VALUES("92","brand","web","2020-02-25 23:59:59","2020-02-25 23:59:59");
INSERT INTO permissions VALUES("93","billers-index","web","2020-02-26 00:11:15","2020-02-26 00:11:15");
INSERT INTO permissions VALUES("94","billers-add","web","2020-02-26 00:11:15","2020-02-26 00:11:15");
INSERT INTO permissions VALUES("95","billers-edit","web","2020-02-26 00:11:15","2020-02-26 00:11:15");
INSERT INTO permissions VALUES("96","billers-delete","web","2020-02-26 00:11:15","2020-02-26 00:11:15");
INSERT INTO permissions VALUES("97","money-transfer","web","2020-03-01 22:41:48","2020-03-01 22:41:48");
INSERT INTO permissions VALUES("98","category","web","2020-07-13 05:13:16","2020-07-13 05:13:16");
INSERT INTO permissions VALUES("99","delivery","web","2020-07-13 05:13:16","2020-07-13 05:13:16");
INSERT INTO permissions VALUES("100","send_notification","web","2020-10-30 23:21:31","2020-10-30 23:21:31");
INSERT INTO permissions VALUES("101","today_sale","web","2020-10-30 23:57:04","2020-10-30 23:57:04");
INSERT INTO permissions VALUES("102","today_profit","web","2020-10-30 23:57:04","2020-10-30 23:57:04");
INSERT INTO permissions VALUES("103","currency","web","2020-11-08 17:23:11","2020-11-08 17:23:11");
INSERT INTO permissions VALUES("104","backup_database","web","2020-11-14 17:16:55","2020-11-14 17:16:55");
INSERT INTO permissions VALUES("105","reward_point_setting","web","2021-06-26 21:34:42","2021-06-26 21:34:42");
INSERT INTO permissions VALUES("106","revenue_profit_summary","web","2022-02-08 06:57:21","2022-02-08 06:57:21");
INSERT INTO permissions VALUES("107","cash_flow","web","2022-02-08 06:57:22","2022-02-08 06:57:22");
INSERT INTO permissions VALUES("108","monthly_summary","web","2022-02-08 06:57:22","2022-02-08 06:57:22");
INSERT INTO permissions VALUES("109","yearly_report","web","2022-02-08 06:57:22","2022-02-08 06:57:22");
INSERT INTO permissions VALUES("110","discount_plan","web","2022-02-16 02:12:26","2022-02-16 02:12:26");
INSERT INTO permissions VALUES("111","discount","web","2022-02-16 02:12:38","2022-02-16 02:12:38");
INSERT INTO permissions VALUES("112","product-expiry-report","web","2022-03-29 22:39:20","2022-03-29 22:39:20");
INSERT INTO permissions VALUES("113","purchase-payment-index","web","2022-06-05 07:12:27","2022-06-05 07:12:27");
INSERT INTO permissions VALUES("114","purchase-payment-add","web","2022-06-05 07:12:28","2022-06-05 07:12:28");
INSERT INTO permissions VALUES("115","purchase-payment-edit","web","2022-06-05 07:12:28","2022-06-05 07:12:28");
INSERT INTO permissions VALUES("116","purchase-payment-delete","web","2022-06-05 07:12:28","2022-06-05 07:12:28");
INSERT INTO permissions VALUES("117","sale-payment-index","web","2022-06-05 07:12:28","2022-06-05 07:12:28");
INSERT INTO permissions VALUES("118","sale-payment-add","web","2022-06-05 07:12:28","2022-06-05 07:12:28");
INSERT INTO permissions VALUES("119","sale-payment-edit","web","2022-06-05 07:12:28","2022-06-05 07:12:28");
INSERT INTO permissions VALUES("120","sale-payment-delete","web","2022-06-05 07:12:28","2022-06-05 07:12:28");
INSERT INTO permissions VALUES("121","all_notification","web","2022-06-05 07:12:29","2022-06-05 07:12:29");
INSERT INTO permissions VALUES("122","sale-report-chart","web","2022-06-05 07:12:29","2022-06-05 07:12:29");
INSERT INTO permissions VALUES("123","dso-report","web","2022-06-05 07:12:29","2022-06-05 07:12:29");
INSERT INTO permissions VALUES("124","product_history","web","2022-08-25 07:04:05","2022-08-25 07:04:05");
INSERT INTO permissions VALUES("125","supplier-due-report","web","2022-08-31 02:46:33","2022-08-31 02:46:33");



CREATE TABLE `pos_setting` (
  `id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `warehouse_id` int(11) NOT NULL,
  `biller_id` int(11) NOT NULL,
  `product_number` int(11) NOT NULL,
  `keybord_active` tinyint(1) NOT NULL,
  `stripe_public_key` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `stripe_secret_key` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  UNIQUE KEY `pos_setting_id_unique` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO pos_setting VALUES("1","3","1","11","1","0","pk_test_ITN7KOYiIsHSCQ0UMRcgaYUB","sk_test_TtQQaawhEYRwa3mU9CzttrEy","2018-09-01 20:17:04","2023-03-21 19:05:44");



CREATE TABLE `product_adjustments` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `adjustment_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `variant_id` int(11) DEFAULT NULL,
  `qty` double NOT NULL,
  `action` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;




CREATE TABLE `product_batches` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `batch_no` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `expired_date` date NOT NULL,
  `qty` double NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO product_batches VALUES("1","71","1001","2023-05-31","13","2021-03-07 01:14:05","2022-05-14 01:50:17");
INSERT INTO product_batches VALUES("2","71","1002","2023-05-31","6","2021-03-07 01:55:06","2021-06-18 07:32:54");
INSERT INTO product_batches VALUES("3","71","1003","2023-09-30","2","2021-03-09 02:42:13","2021-09-21 02:49:37");
INSERT INTO product_batches VALUES("4","22","10001","2021-11-30","1","2021-10-20 00:47:09","2021-10-20 00:47:09");
INSERT INTO product_batches VALUES("5","61","fggnbmxb","2023-08-31","100","2023-04-24 16:06:29","2023-04-24 16:06:29");
INSERT INTO product_batches VALUES("6","63","TRSE","2023-05-31","9","2023-05-02 14:40:58","2023-05-02 14:41:41");



CREATE TABLE `product_purchases` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `purchase_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `product_batch_id` int(11) DEFAULT NULL,
  `variant_id` int(11) DEFAULT NULL,
  `imei_number` text COLLATE utf8mb4_unicode_ci,
  `qty` double NOT NULL,
  `recieved` double NOT NULL,
  `purchase_unit_id` int(11) NOT NULL,
  `net_unit_cost` double NOT NULL,
  `discount` double NOT NULL,
  `tax_rate` double NOT NULL,
  `tax` double NOT NULL,
  `total` double NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=89 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO product_purchases VALUES("66","50","44","","","","1","1","1","1368.04","0","0","0","1368.04","2023-04-03 11:56:13","2023-04-03 11:56:13");
INSERT INTO product_purchases VALUES("81","63","58","","","","322","322","7","5.6","0","0","0","1803.2","2023-04-12 11:40:56","2023-04-12 11:40:56");
INSERT INTO product_purchases VALUES("82","64","59","","","","317","317","7","5.6","0","0","0","1775.2","2023-04-17 12:14:14","2023-04-17 12:14:14");
INSERT INTO product_purchases VALUES("83","65","60","","","","1","1","1","5.7","0","0","0","5.7","2023-04-19 14:28:48","2023-04-19 14:28:48");
INSERT INTO product_purchases VALUES("84","66","60","","","","272","272","7","5.7","0","0","0","1550.4","2023-04-19 14:29:59","2023-04-19 14:29:59");
INSERT INTO product_purchases VALUES("85","67","59","","","","1000","1000","7","5.6","0","0","0","5600","2023-04-24 11:24:19","2023-04-24 11:24:19");
INSERT INTO product_purchases VALUES("86","68","61","5","","","100","100","1","0.75","0","0","0","75","2023-04-24 16:06:29","2023-04-24 16:06:29");
INSERT INTO product_purchases VALUES("87","69","62","","","","1","1","1","5.7","0","0","0","5.7","2023-05-01 16:21:12","2023-05-01 16:21:12");
INSERT INTO product_purchases VALUES("88","70","63","6","","","10","10","1","123","0","0","0","1230","2023-05-02 14:40:58","2023-05-02 14:40:58");



CREATE TABLE `product_quotation` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `quotation_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `product_batch_id` int(11) DEFAULT NULL,
  `variant_id` int(11) DEFAULT NULL,
  `qty` double NOT NULL,
  `sale_unit_id` int(11) NOT NULL,
  `net_unit_price` double NOT NULL,
  `discount` double NOT NULL,
  `tax_rate` double NOT NULL,
  `tax` double NOT NULL,
  `total` double NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO product_quotation VALUES("1","1","40","","","1","1","1007.12","0","0","0","1007.12","2023-03-29 15:34:02","2023-03-29 15:34:02");
INSERT INTO product_quotation VALUES("2","2","40","","","1","1","1007.12","0","0","0","1007.12","2023-03-29 15:39:44","2023-03-29 15:39:44");



CREATE TABLE `product_returns` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `return_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `product_batch_id` int(11) DEFAULT NULL,
  `variant_id` int(11) DEFAULT NULL,
  `imei_number` text COLLATE utf8mb4_unicode_ci,
  `qty` double NOT NULL,
  `sale_unit_id` int(11) NOT NULL,
  `net_unit_price` double NOT NULL,
  `discount` double NOT NULL,
  `tax_rate` double NOT NULL,
  `tax` double NOT NULL,
  `total` double NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=64 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO product_returns VALUES("3","2","4","","","","20","1","2","0","0","0","40","","");
INSERT INTO product_returns VALUES("4","3","10","","","","2","7","22","0","0","0","44","","2018-10-06 19:19:40");
INSERT INTO product_returns VALUES("6","5","3","","","","1","1","250","0","0","0","250","","2018-12-25 15:16:08");
INSERT INTO product_returns VALUES("12","6","1","","","","1","1","400","0","10","40","440","","");
INSERT INTO product_returns VALUES("23","11","13","","","","1","0","21","0","0","0","21","2019-12-23 22:20:29","2019-12-23 22:20:29");
INSERT INTO product_returns VALUES("26","13","61","","","","1","1","10000","0","15","1500","11500","2020-08-16 09:25:02","2020-08-16 09:25:02");
INSERT INTO product_returns VALUES("27","14","1","","","","1","1","400","0","10","40","440","2020-10-13 04:39:54","2020-10-13 04:39:54");
INSERT INTO product_returns VALUES("31","18","61","","","","1","1","10000","0","15","1500","11500","2020-11-17 18:02:18","2020-11-17 18:02:18");
INSERT INTO product_returns VALUES("32","19","3","","","","1","1","250","0","0","0","250","2020-12-09 17:40:25","2020-12-09 17:40:25");
INSERT INTO product_returns VALUES("58","33","25","","","","1","1","1000","0","10","100","1100","2022-05-30 23:33:40","2022-05-30 23:33:40");
INSERT INTO product_returns VALUES("59","34","1","","","","1","1","400","0","10","40","440","2022-05-30 23:48:17","2022-05-30 23:48:17");
INSERT INTO product_returns VALUES("61","36","22","","","","1","1","1000","0","10","100","1100","2022-06-14 02:20:48","2022-06-14 02:20:48");
INSERT INTO product_returns VALUES("63","38","3","","","","1","1","250","0","0","0","250","2022-09-04 00:19:08","2022-09-04 00:19:08");



CREATE TABLE `product_sales` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `sale_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `product_batch_id` int(11) DEFAULT NULL,
  `net_weight` double(20,2) DEFAULT NULL,
  `gross_weight` double(20,2) DEFAULT NULL,
  `variant_id` int(11) DEFAULT NULL,
  `imei_number` text COLLATE utf8mb4_unicode_ci,
  `qty` double NOT NULL,
  `sale_unit_id` int(11) NOT NULL,
  `net_unit_price` double NOT NULL,
  `discount` double NOT NULL,
  `tax_rate` double NOT NULL,
  `tax` double NOT NULL,
  `total` double NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=95 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO product_sales VALUES("70","57","44","","","","","","1","1","1573.2","0","0","0","1573.2","2023-04-16 00:00:00","2023-04-03 12:59:34");
INSERT INTO product_sales VALUES("86","73","57","","","","","","322","7","6.35","0","0","0","2044.7","2023-04-07 00:00:00","2023-04-12 11:32:52");
INSERT INTO product_sales VALUES("87","74","57","","10.00","12.00","","","1","7","6.35","0","0","0","6.35","2023-04-10 00:00:00","2023-04-10 12:33:48");
INSERT INTO product_sales VALUES("88","75","58","","322.00","322.00","","","322","7","6.35","0","0","0","2044.7","2023-04-12 00:00:00","2023-04-12 11:43:13");
INSERT INTO product_sales VALUES("89","76","59","","316.64","316.64","","","334","7","6.35","0","0","0","2120.9","2023-04-17 00:00:00","2023-04-24 11:25:42");
INSERT INTO product_sales VALUES("90","77","60","","","","","","272","7","6","0","0","0","1632","2023-04-19 00:00:00","2023-04-19 14:31:18");
INSERT INTO product_sales VALUES("91","78","61","5","0.90","0.90","","","50","1","1.5","0","0","0","75","2023-04-24 00:00:00","2023-04-24 16:13:06");
INSERT INTO product_sales VALUES("93","82","62","","20.00","20.00","","","1","1","6.3","0","0","0","6.3","2023-05-02 00:00:00","2023-05-02 14:28:59");
INSERT INTO product_sales VALUES("94","83","63","6","1.00","1.50","","","1","1","124","0","0","0","124","2023-05-02 00:00:00","2023-05-02 14:41:41");



CREATE TABLE `product_transfer` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `transfer_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `product_batch_id` int(11) DEFAULT NULL,
  `variant_id` int(11) DEFAULT NULL,
  `imei_number` text COLLATE utf8mb4_unicode_ci,
  `qty` double NOT NULL,
  `purchase_unit_id` int(11) NOT NULL,
  `net_unit_cost` double NOT NULL,
  `tax_rate` double NOT NULL,
  `tax` double NOT NULL,
  `total` double NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;




CREATE TABLE `product_variants` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `variant_id` int(11) NOT NULL,
  `position` int(11) NOT NULL,
  `item_code` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `additional_cost` double DEFAULT NULL,
  `additional_price` double DEFAULT NULL,
  `qty` double NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=55 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO product_variants VALUES("3","48","3","1","S-93475396","","","12","2019-11-21 00:03:04","2021-07-15 05:25:45");
INSERT INTO product_variants VALUES("5","48","5","3","L-93475396","10","50","12","2019-11-23 23:07:20","2022-08-08 08:34:26");
INSERT INTO product_variants VALUES("6","48","2","2","M-93475396","5","10","13","2019-11-24 00:17:07","2022-08-08 08:13:57");
INSERT INTO product_variants VALUES("10","60","9","1","a-32081679","","","1","2020-05-18 09:44:14","2020-10-26 16:42:06");
INSERT INTO product_variants VALUES("11","60","11","2","b-32081679","","","0","2020-05-18 09:58:31","2020-05-18 09:58:31");
INSERT INTO product_variants VALUES("12","62","12","1","variant 1-81145830","","","3","2020-09-26 23:08:27","2021-02-10 18:28:16");
INSERT INTO product_variants VALUES("13","62","13","2","variant 2-81145830","","","0","2020-09-26 23:08:27","2020-09-26 23:08:27");
INSERT INTO product_variants VALUES("26","87","18","1","s/red-82490498","","","0","2022-08-02 22:25:19","2022-08-02 22:25:19");
INSERT INTO product_variants VALUES("27","87","24","2","s/blue-82490498","","","0","2022-08-02 22:25:19","2022-08-02 22:25:19");
INSERT INTO product_variants VALUES("28","87","20","4","m/red-82490498","","","0","2022-08-02 22:25:19","2022-08-05 22:54:37");
INSERT INTO product_variants VALUES("29","87","25","5","m/blue-82490498","","","0","2022-08-02 22:25:20","2022-08-05 22:54:37");
INSERT INTO product_variants VALUES("30","87","22","7","l/red-82490498","2","5","1","2022-08-02 22:25:20","2022-08-08 08:13:57");
INSERT INTO product_variants VALUES("31","87","26","8","l/blue-82490498","2","5","0","2022-08-02 22:25:20","2022-08-05 22:54:37");
INSERT INTO product_variants VALUES("32","87","27","3","s/green-82490498","","","0","2022-08-05 22:54:37","2022-08-05 22:54:37");
INSERT INTO product_variants VALUES("33","87","28","6","m/green-82490498","","","0","2022-08-05 22:54:37","2022-08-05 22:54:37");
INSERT INTO product_variants VALUES("34","87","29","9","l/green-82490498","2","5","0","2022-08-05 22:54:37","2022-08-08 06:58:47");
INSERT INTO product_variants VALUES("38","87","30","10","xl/red-82490498","3","6","-1","2022-08-08 07:05:58","2022-11-17 04:07:49");
INSERT INTO product_variants VALUES("39","87","31","11","xl/blue-82490498","3","6","0","2022-08-08 07:05:58","2022-08-08 07:05:58");
INSERT INTO product_variants VALUES("40","87","32","12","xl/green-82490498","3","6","0","2022-08-08 07:05:58","2022-08-08 07:05:58");
INSERT INTO product_variants VALUES("43","90","33","1","red-17628500","","","10","2022-09-10 23:56:55","2022-09-11 00:04:41");
INSERT INTO product_variants VALUES("44","90","34","2","black-17628500","","","10","2022-09-10 23:56:55","2022-09-11 00:04:41");
INSERT INTO product_variants VALUES("45","90","35","3","blue-17628500","50","100","9","2022-09-10 23:56:55","2022-09-11 00:18:26");
INSERT INTO product_variants VALUES("46","91","36","1","black/12.5-06243672","","","0","2022-11-17 03:50:30","2022-11-17 03:50:30");
INSERT INTO product_variants VALUES("50","91","40","2","gold/12.5-06243672","","","0","2022-11-17 03:50:30","2022-11-17 03:54:29");
INSERT INTO product_variants VALUES("54","91","44","3","silver/12.5-06243672","","","0","2022-11-17 03:50:30","2022-11-17 03:54:29");



CREATE TABLE `product_warehouse` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `product_id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_batch_id` int(11) DEFAULT NULL,
  `variant_id` int(11) DEFAULT NULL,
  `imei_number` text COLLATE utf8mb4_unicode_ci,
  `warehouse_id` int(11) NOT NULL,
  `qty` double NOT NULL,
  `price` double DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=62 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO product_warehouse VALUES("1","1","","","","1","0","","2023-03-14 16:47:13","2023-03-15 23:48:42");
INSERT INTO product_warehouse VALUES("2","2","","","","2","6","280","2023-03-14 17:31:17","2023-03-15 22:31:56");
INSERT INTO product_warehouse VALUES("3","3","","","","1","6","16","2023-03-14 17:32:39","2023-03-21 18:13:03");
INSERT INTO product_warehouse VALUES("4","4","","","","1","0","105","2023-03-14 19:01:32","2023-03-14 19:03:37");
INSERT INTO product_warehouse VALUES("5","1","","","","2","-3","","2023-03-18 15:56:20","2023-03-20 17:15:54");
INSERT INTO product_warehouse VALUES("6","3","","","","2","0","1050","2023-03-20 17:19:48","2023-03-21 18:13:03");
INSERT INTO product_warehouse VALUES("7","2","","","","1","0","","2023-03-20 17:21:25","2023-03-21 17:51:00");
INSERT INTO product_warehouse VALUES("8","4","","","","2","0","","2023-03-21 18:56:06","2023-03-21 17:51:00");
INSERT INTO product_warehouse VALUES("9","5","","","","1","0","7","2023-03-21 19:03:23","2023-03-21 18:13:03");
INSERT INTO product_warehouse VALUES("10","6","","","","1","0","8694","2023-03-21 22:06:30","2023-03-27 11:56:52");
INSERT INTO product_warehouse VALUES("11","7","","","","1","0","7728","2023-03-21 22:09:48","2023-03-27 11:56:52");
INSERT INTO product_warehouse VALUES("12","8","","","","1","0","490996","2023-03-21 22:12:12","2023-03-27 11:56:52");
INSERT INTO product_warehouse VALUES("13","9","","","","1","0","70000","2023-03-21 22:15:04","2023-03-27 11:56:52");
INSERT INTO product_warehouse VALUES("14","10","","","","1","0","127000","2023-03-21 22:16:38","2023-03-27 11:56:52");
INSERT INTO product_warehouse VALUES("15","11","","","","1","0","452410","2023-03-21 22:18:09","2023-03-27 11:56:52");
INSERT INTO product_warehouse VALUES("16","12","","","","1","0","112000","2023-03-21 22:20:13","2023-03-27 11:56:52");
INSERT INTO product_warehouse VALUES("17","15","","","","1","0","62.1","2023-03-23 12:45:40","2023-03-27 11:55:52");
INSERT INTO product_warehouse VALUES("18","16","","","","1","0","62.1","2023-03-23 13:15:46","2023-04-10 10:32:06");
INSERT INTO product_warehouse VALUES("19","17","","","","1","0","55.2","2023-03-23 14:03:17","2023-04-10 10:32:06");
INSERT INTO product_warehouse VALUES("20","18","","","","1","0","410.4","2023-03-23 14:14:05","2023-04-10 10:32:06");
INSERT INTO product_warehouse VALUES("21","19","","","","1","0","3096.71","2023-03-23 14:31:58","2023-03-27 11:55:52");
INSERT INTO product_warehouse VALUES("22","20","","","","1","0","500","2023-03-23 14:50:02","2023-04-10 10:32:06");
INSERT INTO product_warehouse VALUES("23","21","","","","1","0","907.14","2023-03-23 16:03:04","2023-04-10 10:32:06");
INSERT INTO product_warehouse VALUES("24","22","","","","1","0","3231.5","2023-03-23 16:06:43","2023-04-10 10:32:06");
INSERT INTO product_warehouse VALUES("25","23","","","","1","0","800","2023-03-23 16:27:01","2023-04-10 10:32:06");
INSERT INTO product_warehouse VALUES("26","24","","","","1","0","","2023-03-27 11:31:27","2023-03-27 11:55:52");
INSERT INTO product_warehouse VALUES("27","25","","","","1","0","","2023-03-27 12:28:22","2023-04-10 10:32:06");
INSERT INTO product_warehouse VALUES("28","26","","","","1","0","","2023-03-27 14:17:39","2023-04-03 16:08:12");
INSERT INTO product_warehouse VALUES("29","27","","","","1","0","","2023-03-27 14:18:53","2023-04-03 16:08:12");
INSERT INTO product_warehouse VALUES("30","28","","","","1","0","","2023-03-27 14:19:24","2023-04-03 16:08:12");
INSERT INTO product_warehouse VALUES("31","29","","","","1","0","","2023-03-27 14:20:07","2023-04-03 16:08:12");
INSERT INTO product_warehouse VALUES("32","30","","","","1","0","","2023-03-27 14:21:27","2023-04-03 16:08:00");
INSERT INTO product_warehouse VALUES("33","31","","","","1","0","","2023-03-27 14:21:56","2023-04-03 16:08:00");
INSERT INTO product_warehouse VALUES("34","32","","","","1","0","","2023-03-27 14:22:27","2023-04-03 16:08:00");
INSERT INTO product_warehouse VALUES("35","33","","","","1","0","","2023-03-27 14:23:05","2023-04-03 16:08:00");
INSERT INTO product_warehouse VALUES("36","34","","","","1","0","","2023-03-27 14:23:52","2023-04-03 16:08:00");
INSERT INTO product_warehouse VALUES("37","35","","","","1","0","","2023-03-27 14:26:40","2023-04-03 16:08:00");
INSERT INTO product_warehouse VALUES("38","36","","","","1","0","","2023-03-27 14:35:08","2023-04-03 16:08:00");
INSERT INTO product_warehouse VALUES("39","37","","","","1","0","","2023-03-27 14:39:07","2023-04-03 16:08:00");
INSERT INTO product_warehouse VALUES("40","38","","","","1","0","","2023-03-27 14:40:32","2023-04-03 16:08:00");
INSERT INTO product_warehouse VALUES("41","40","","","","1","0","","2023-03-29 15:28:21","2023-04-10 10:31:59");
INSERT INTO product_warehouse VALUES("42","41","","","","1","0","","2023-03-31 12:52:54","2023-04-10 10:32:06");
INSERT INTO product_warehouse VALUES("43","42","","","","1","0","","2023-04-03 11:51:41","2023-04-10 10:31:59");
INSERT INTO product_warehouse VALUES("44","43","","","","1","0","","2023-04-03 11:52:59","2023-04-10 10:32:06");
INSERT INTO product_warehouse VALUES("45","44","","","","1","0","","2023-04-03 11:56:13","2023-04-10 10:32:06");
INSERT INTO product_warehouse VALUES("46","45","","","","1","0","","2023-04-03 11:57:30","2023-04-10 10:31:59");
INSERT INTO product_warehouse VALUES("47","46","","","","1","0","","2023-04-03 11:58:26","2023-04-10 10:31:59");
INSERT INTO product_warehouse VALUES("48","47","","","","1","0","","2023-04-03 11:59:10","2023-04-10 10:31:59");
INSERT INTO product_warehouse VALUES("49","48","","","","1","0","","2023-04-03 11:59:49","2023-04-10 10:31:59");
INSERT INTO product_warehouse VALUES("50","49","","","","1","0","","2023-04-03 12:00:57","2023-04-10 10:31:59");
INSERT INTO product_warehouse VALUES("51","51","","","","1","0","","2023-04-03 12:03:31","2023-04-10 10:31:59");
INSERT INTO product_warehouse VALUES("52","53","","","","1","0","","2023-04-03 16:12:07","2023-04-10 10:32:12");
INSERT INTO product_warehouse VALUES("53","54","","","","1","0","1614.57","2023-04-03 16:47:28","2023-04-10 10:31:59");
INSERT INTO product_warehouse VALUES("54","55","","","","1","0","","2023-04-04 11:45:31","2023-04-10 10:31:59");
INSERT INTO product_warehouse VALUES("55","57","","","","1","-323","","2023-04-10 10:37:18","2023-04-12 11:32:52");
INSERT INTO product_warehouse VALUES("56","58","","","","1","0","","2023-04-12 11:40:56","2023-04-12 11:43:13");
INSERT INTO product_warehouse VALUES("57","59","","","","1","983","","2023-04-17 12:14:14","2023-04-24 11:25:42");
INSERT INTO product_warehouse VALUES("58","60","","","","1","1","6","2023-04-19 14:28:48","2023-04-19 14:31:18");
INSERT INTO product_warehouse VALUES("59","61","5","","","2","100","","2023-04-24 16:06:29","2023-04-24 16:06:29");
INSERT INTO product_warehouse VALUES("60","62","","","","1","0","","2023-05-01 16:21:12","2023-05-02 14:28:59");
INSERT INTO product_warehouse VALUES("61","63","6","","","1","9","","2023-05-02 14:40:58","2023-05-02 14:41:41");



CREATE TABLE `products` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `barcode_symbology` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `brand_id` int(11) DEFAULT NULL,
  `category_id` int(11) NOT NULL,
  `unit_id` int(11) NOT NULL,
  `purchase_unit_id` int(11) NOT NULL,
  `sale_unit_id` int(11) NOT NULL,
  `cost` double NOT NULL,
  `price` double NOT NULL,
  `qty` double DEFAULT NULL,
  `alert_quantity` double DEFAULT NULL,
  `daily_sale_objective` double DEFAULT NULL,
  `promotion` tinyint(4) DEFAULT NULL,
  `promotion_price` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `starting_date` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_date` date DEFAULT NULL,
  `tax_id` int(11) DEFAULT NULL,
  `tax_method` int(11) DEFAULT NULL,
  `image` longtext COLLATE utf8mb4_unicode_ci,
  `file` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_embeded` tinyint(1) DEFAULT NULL,
  `is_variant` tinyint(1) DEFAULT NULL,
  `is_batch` tinyint(1) DEFAULT NULL,
  `is_diffPrice` tinyint(1) DEFAULT NULL,
  `is_imei` tinyint(1) DEFAULT NULL,
  `featured` tinyint(4) DEFAULT NULL,
  `product_list` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `variant_list` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `qty_list` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `price_list` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `product_details` text COLLATE utf8mb4_unicode_ci,
  `variant_option` text COLLATE utf8mb4_unicode_ci,
  `variant_value` text COLLATE utf8mb4_unicode_ci,
  `is_active` tinyint(1) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `temp_product_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `net_weight` double(20,2) DEFAULT NULL,
  `gross_weight` double(20,2) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=64 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO products VALUES("2","watch","28953098","standard","C128","5","1","1","1","1","100","110","0","1","","","","","","","1","zummXD2dvAtI.png","","","","","","","","","","","","","","","0","2023-03-20 17:18:17","2023-03-23 12:37:32","","","");
INSERT INTO products VALUES("3","SamSung Mobile","01203199","standard","C128","","1","1","1","1","1000","1050","0","1","","","","","","","","zummXD2dvAtI.png","","","","","","","","","","","","","","","0","2023-03-20 17:19:48","2023-03-23 12:37:27","","","");
INSERT INTO products VALUES("4","Mouse","58198047","standard","C128","5","1","1","1","1","50","55","0","1","","","","","","","1","zummXD2dvAtI.png","","","","","","","","","","","","","","","0","2023-03-21 18:53:45","2023-03-23 12:37:01","","","");
INSERT INTO products VALUES("5","Pen","75701329","standard","C128","","1","1","1","1","5","7","0","1","","","","","","","","zummXD2dvAtI.png","","","","","","","","","","","","","","","0","2023-03-21 19:03:23","2023-03-23 12:37:17","","","");
INSERT INTO products VALUES("6","car parts 1","carparts01022023","standard","C128","","1","1","1","1","7273","8694","0","1","","","","","","","","zummXD2dvAtI.png","","","","","","","","","","","","","","","0","2023-03-21 22:06:30","2023-03-27 11:56:52","car parts 1","","");
INSERT INTO products VALUES("7","car parts2","carparts02 -01022023","standard","C128","","1","1","1","1","6361","7728","0","1","","","","","","","","zummXD2dvAtI.png","","","","","","","","","","","","","","","0","2023-03-21 22:09:48","2023-03-27 11:56:52","","","");
INSERT INTO products VALUES("8","carparts3","carparts06022023","standard","C128","","1","1","1","1","409698","490996","0","1","","","","","","","","zummXD2dvAtI.png","","","","","","","","","","","","","","","0","2023-03-21 22:12:12","2023-03-27 11:56:52","carparts3","","");
INSERT INTO products VALUES("9","car parts 4","carparts08022023","standard","C128","","1","1","1","1","53110","70000","0","1","","","","","","","","zummXD2dvAtI.png","","","","","","","","","","","","","","","0","2023-03-21 22:15:04","2023-03-27 11:56:52","car parts 4","","");
INSERT INTO products VALUES("10","car parts 5","carparts13022023","standard","C128","","1","1","1","1","60750","127000","0","1","","","","","","","","zummXD2dvAtI.png","","","","","","","","","","","","","","","0","2023-03-21 22:16:38","2023-03-27 11:56:52","car parts 5","","");
INSERT INTO products VALUES("11","car parts 6","carparts16022023","standard","C128","","1","1","1","1","349920","452410","0","1","","","","","","","","zummXD2dvAtI.png","","","","","","","","","","","","","","","0","2023-03-21 22:18:09","2023-03-27 11:56:52","car parts 6","","");
INSERT INTO products VALUES("12","car parts 7","carparts20022023","standard","C128","","1","1","1","1","63450","112000","0","1","","","","","","","","zummXD2dvAtI.png","","","","","","","","","","","","","","","0","2023-03-21 22:20:13","2023-03-27 11:56:52","car parts 7","","");
INSERT INTO products VALUES("13","Cargo bill","48870712","standard","C128","10","1","7","7","7","12000","15000","0","0","","","","","","","1","zummXD2dvAtI.png","","","","","","","","","","","","","","","0","2023-03-23 00:04:35","2023-03-23 12:37:01","","","");
INSERT INTO products VALUES("14","Car Keys","90681452","standard","C128","11","1","1","1","1","53.88","62.1","0","1","","","","","","","1","zummXD2dvAtI.png","","0","","","0","","0","","","","","<p>Car Keys from eBay units-4&nbsp;</p>
<p>Exchange rate @140</p>","","","0","2023-03-23 12:35:54","2023-03-23 13:13:06","","","");
INSERT INTO products VALUES("15","Car Keys","09275441","standard","C128","","1","1","1","1","53.88","62.1","0","1","","","","","","","","zummXD2dvAtI.png","","","","","","","","","","","","","","","0","2023-03-23 12:45:40","2023-03-27 11:55:52","","","");
INSERT INTO products VALUES("16","Car Keys","63405217","standard","C128","","1","1","1","1","53.88","62.1","0","1","","","","","","","","zummXD2dvAtI.png","","","","","","","","","","","","","","","0","2023-03-23 13:15:46","2023-04-10 13:29:22","","","");
INSERT INTO products VALUES("17","Car Keys","03251238","standard","C128","","1","1","1","1","47.12","55.2","0","1","","","","","","","","zummXD2dvAtI.png","","","","","","","","","","","","","","","0","2023-03-23 14:03:17","2023-04-10 13:29:22","","","");
INSERT INTO products VALUES("18","EV One Stop Charging Cabel","33203170","standard","C128","","1","1","1","1","342","410.4","0","1","","","","","","","","zummXD2dvAtI.png","","","","","","","","","","","","","","","0","2023-03-23 14:14:05","2023-04-10 13:29:44","EV One Stop Charging Cabel","","");
INSERT INTO products VALUES("19","Wall Pod","80216451","standard","C128","","1","1","1","1","2692.8","3096.71","0","1","","","","","","","","zummXD2dvAtI.png","","","","","","","","","","","","","","","0","2023-03-23 14:31:58","2023-04-10 13:30:08","","","");
INSERT INTO products VALUES("20","Audi Service parts","02311375","standard","C128","","1","1","1","1","393.41","500","0","1","","","","","","","","zummXD2dvAtI.png","","","","","","","","","","","","","","","0","2023-03-23 14:50:02","2023-04-10 13:29:22","","","");
INSERT INTO products VALUES("21","VW Parts","26113430","standard","C128","","1","1","1","1","450","907.14","0","1","","","","","","","","zummXD2dvAtI.png","","","","","","","","","","","","","","","0","2023-03-23 16:03:04","2023-04-10 13:30:08","","","");
INSERT INTO products VALUES("22","Range Rover Steering Box","81139730","standard","C128","","1","1","1","1","2592.13","3231.5","0","1","","","","","","","","zummXD2dvAtI.png","","","","","","","","","","","","","","","0","2023-03-23 16:06:43","2023-04-10 13:30:01","","","");
INSERT INTO products VALUES("23","Land Rover","03235116","standard","C128","","1","1","1","1","469.97","800","0","1","","","","","","","","zummXD2dvAtI.png","","","","","","","","","","","","","","","0","2023-03-23 16:27:01","2023-04-10 13:29:44","","","");
INSERT INTO products VALUES("24","BMW","09393616","standard","C128","11","1","1","1","1","1000","1200","0","1","","","","2023-03-27","","","1","zummXD2dvAtI.png","","","","","","1","","","","","","<p>BMW Control Unit</p>","","","0","2023-03-27 11:27:32","2023-04-10 13:29:22","BMW","","");
INSERT INTO products VALUES("25","EV Onestop  Charging Cabel-3","40507012","standard","C128","","1","1","1","1","2692.8","3096.71","0","1","","","","","","","1","1679916378244evonestop.jpeg","","","","","","","","","","","","","","","0","2023-03-27 12:26:29","2023-04-10 13:29:44","","","");
INSERT INTO products VALUES("26","Toyota Parts","11429631","standard","C128","16","1","1","1","1","1408.07","1548.8","0","","","","","","","","1","zummXD2dvAtI.png","","","","","","","","","","","","","","","0","2023-03-27 13:38:10","2023-04-10 13:30:01","Toyota Parts","","");
INSERT INTO products VALUES("27","Mercedes service parts","23649804","standard","C128","14","1","1","1","1","2022.36","2343","0","","","","","","","","1","zummXD2dvAtI.png","","0","","","0","","0","","","","","","","","0","2023-03-27 13:42:52","2023-04-10 13:30:01","Mercedes service parts","","");
INSERT INTO products VALUES("28","EBAYJan10","34799033","standard","C128","","1","1","1","1","14.49","16.49","0","","","","","","","","1","zummXD2dvAtI.png","","","","","","","","","","","","","","","0","2023-03-27 13:44:47","2023-04-10 13:29:44","EBAYJan10","","");
INSERT INTO products VALUES("29","BMWJAN12","52017920","standard","C128","11","1","1","1","1","1143.25","1275.26","0","1","","","","","","","1","zummXD2dvAtI.png","","0","","","0","","0","","","","","","","","0","2023-03-27 13:48:08","2023-04-10 13:29:22","","","");
INSERT INTO products VALUES("30","GLYN HOPKINJAN14","60029401","standard","C128","","1","1","1","1","663.34","764.75","0","","","","","","","","1","zummXD2dvAtI.png","","","","","","","","","","","","","","","0","2023-03-27 13:51:58","2023-04-10 13:29:44","GLYN HOPKINJAN14","","");
INSERT INTO products VALUES("31","Ebay17JANA","92665980","standard","C128","","1","1","1","1","100","300","0","","","","","","","","1","zummXD2dvAtI.png","","","","","","","","","","","","","","","0","2023-03-27 13:59:42","2023-04-10 13:29:34","Ebay17JANA","","");
INSERT INTO products VALUES("32","EBAY17JANB","57613122","standard","C128","","1","1","1","1","70","200","0","","","","","","","","1","zummXD2dvAtI.png","","","","","","","","","","","","","","","0","2023-03-27 14:01:22","2023-04-10 13:29:34","EBAY17JANB","","");
INSERT INTO products VALUES("33","BMWWIP62262","96808931","standard","C128","11","1","1","1","1","1026.73","1179.89","0","","","","","","","","1","zummXD2dvAtI.png","","","","","","","","","","","","","","","0","2023-03-27 14:03:07","2023-04-10 13:29:22","BMWWIP62262","","");
INSERT INTO products VALUES("34","Ebay15JAN","52345301","standard","C128","","1","1","1","1","14.85","28.51","0","","","","","","","","1","zummXD2dvAtI.png","","","","","","","","","","","","","","","0","2023-03-27 14:05:15","2023-04-10 13:29:34","Ebay15JAN","","");
INSERT INTO products VALUES("35","Volvo SERVICE PART JAN","45368295","standard","C128","18","1","1","1","1","705.14","852.24","0","","","","","","","","1","zummXD2dvAtI.png","","","","","","","","","","","","","","","0","2023-03-27 14:07:04","2023-04-10 13:30:01","Volvo SERVICE PART JAN","","");
INSERT INTO products VALUES("36","BMW SERVICE PART JAN 25","21016543","standard","C128","11","1","1","1","1","5446.88","6495.9","0","","","","","","","","1","zummXD2dvAtI.png","","","","","","","","","","","","","","","0","2023-03-27 14:09:09","2023-04-10 13:29:22","BMW SERVICE PART JAN 25","","");
INSERT INTO products VALUES("37","RANGE ROVER SERVICE PART JAN 25","40425981","standard","C128","15","1","1","1","1","2688.01","3454.16","0","","","","","","","","1","zummXD2dvAtI.png","","","","","","","","","","","","","","","0","2023-03-27 14:12:33","2023-04-10 13:30:01","RANGE ROVER SERVICE PART JAN 25","","");
INSERT INTO products VALUES("38","CHARGER 156157","49761821","standard","C128","","1","1","1","1","1275.77","1618.71","0","","","","","","","","1","zummXD2dvAtI.png","","","","","","","","","","","","","","","0","2023-03-27 14:14:40","2023-04-10 13:29:34","","","");
INSERT INTO products VALUES("39","Alfa Romeo ABS","30415912","standard","C128","","1","1","1","1","40","48","0","1","","","","","","","1","zummXD2dvAtI.png","","0","","","0","","0","","","","","","","","0","2023-03-28 16:00:29","2023-04-10 13:29:22","","","");
INSERT INTO products VALUES("40","Land Rover Service Parts","30947427","standard","C128","15","1","1","1","1","788.18","1007.12","0","2","","","","","","","1","zummXD2dvAtI.png","","0","","","0","","0","","","","","","","","0","2023-03-29 15:25:18","2023-04-10 13:29:44","","","");
INSERT INTO products VALUES("41","Chrysler Clliper","77605131","standard","C128","","1","1","1","1","108.95","299","0","1","","","","","","","1","zummXD2dvAtI.png","","","","","","","","","","","","","","","0","2023-03-31 12:50:59","2023-04-10 13:29:34","","","");
INSERT INTO products VALUES("42","Ebay Chrysler","68977981","standard","C128","","1","1","1","1","108.95","299","0","","","","","","","","1","zummXD2dvAtI.png","","","","","","","","","","","","","","","0","2023-04-03 11:11:13","2023-04-10 13:29:34","Trepsdfvgsdisdgy","","");
INSERT INTO products VALUES("43","P and P Autoservice LTD","53014356","standard","C128","","1","1","1","1","1800","1980","0","","","","","","","","1","zummXD2dvAtI.png","","","","","","","","","","","","","","","0","2023-04-03 11:13:50","2023-04-10 13:30:01","","","");
INSERT INTO products VALUES("44","volvo24486","71820309","standard","C128","18","1","1","1","1","1368.04","1573.2","0","","","","","","","","1","zummXD2dvAtI.png","","","","","","","","","","","","","","","0","2023-04-03 11:15:59","2023-04-10 13:30:01","","","");
INSERT INTO products VALUES("45","Land Rover159021","99617027","standard","C128","15","1","1","1","1","606.08","740.76","0","","","","","","","","1","zummXD2dvAtI.png","","","","","","","","","","","","","","","0","2023-04-03 11:19:16","2023-04-10 13:30:01","","","");
INSERT INTO products VALUES("46","Mercedes service parts WIP-46917","63109549","standard","C128","","1","1","1","1","1463.4","1869.9","0","","","","","","","","1","zummXD2dvAtI.png","","0","","","0","","0","","","","","","","","0","2023-04-03 11:22:00","2023-04-10 13:30:01","","","");
INSERT INTO products VALUES("47","BMW SERVICE PART22march23","12430867","standard","C128","11","1","1","1","1","1218.3","1400.7","0","","","","","","","","1","zummXD2dvAtI.png","","","","","","","","","","","","","","","0","2023-04-03 11:25:44","2023-04-10 13:29:22","","","");
INSERT INTO products VALUES("48","Ebay Charger unit-2","43358739","standard","C128","","1","1","1","1","450","1560.9","0","","","","","","","","1","zummXD2dvAtI.png","","","","","","","","","","","","","","","0","2023-04-03 11:27:57","2023-04-10 13:29:34","","","");
INSERT INTO products VALUES("49","Height Sensor (ANR4687)_2Pcs","93750606","standard","C128","","1","1","1","1","83.42","200","0","","","","","","","","1","zummXD2dvAtI.png","","","","","","","","","","","","","","","0","2023-04-03 11:36:02","2023-04-10 13:29:44","","","");
INSERT INTO products VALUES("50","Land Rover Service Parts160085","79452819","standard","C128","15","1","1","1","1","788.18","1007.12","0","","","","","","","","1","zummXD2dvAtI.png","","","","","","","","","","","","","","","0","2023-04-03 11:41:46","2023-04-10 13:30:01","","","");
INSERT INTO products VALUES("51","Ebay 30march2023","94017658","standard","C128","","1","1","1","1","120","187.14","0","","","","","","","","1","zummXD2dvAtI.png","","","","","","","","","","","","","","","0","2023-04-03 11:44:05","2023-04-10 13:29:34","","","");
INSERT INTO products VALUES("52","Ebay 30march2023","94017658","standard","C128","","1","1","1","1","120","187.14","0","","","","","","","","1","zummXD2dvAtI.png","","","","","","","","","","","","","","","0","2023-04-03 11:44:05","2023-04-10 13:29:34","","","");
INSERT INTO products VALUES("53","Januarypurchase2023","53820681","standard","C128","","1","1","1","1","16578.89","19406.22","0","","","","","","","","1","zummXD2dvAtI.png","","","","","","","","","","","","","","","0","2023-04-03 16:11:01","2023-04-10 13:29:44","","","");
INSERT INTO products VALUES("54","Johir vai freight fees jan-march","19193653","standard","C128","","1","1","1","1","0","1614.57","0","1","","","","","","","","zummXD2dvAtI.png","","","","","","","","","","","","","","","0","2023-04-03 16:47:28","2023-04-10 13:29:44","","","");
INSERT INTO products VALUES("55","BMW X5","54732918","standard","C128","11","1","1","1","1","406.4","466.9","0","1","","","","","","","1","zummXD2dvAtI.png","","","","","","","","","","","","","","","0","2023-04-04 11:44:19","2023-04-10 13:29:22","","","");
INSERT INTO products VALUES("56","FedEx bill","53201499","standard","C128","","1","1","1","1","65.22","81","0","1","","","","","","","1","zummXD2dvAtI.png","","","","","","","","","","","","","","","0","2023-04-04 23:30:47","2023-04-10 13:29:44","","","");
INSERT INTO products VALUES("57","Cargo Bill","61935089","standard","C128","","1","7","7","7","5.6","6.35","-323","1","","","","","","","1","zummXD2dvAtI.png","","0","","","0","","0","","","","","","","","0","2023-04-10 10:37:18","2023-04-12 11:32:52","Cargo Bill - TEST","","");
INSERT INTO products VALUES("58","Cargo Bill","90210568","standard","C128","","2","7","7","7","5.6","6.35","0","5","","","","","","","1","1681130045167images.png","","0","","","0","","0","","","","","","","","1","2023-04-10 13:34:11","2023-04-12 11:43:13","","322.00","322.00");
INSERT INTO products VALUES("59","Cargo Bill/14","51359772","standard","C128","","2","7","7","7","5.6","6.35","983","5","","","","","","","1","zummXD2dvAtI.png","","","","","","","","","","","","<p>Mix Cosmetic and Chocolates (23 Boxes)</p>","","","1","2023-04-17 12:11:36","2023-04-24 11:25:42","","316.64","316.64");
INSERT INTO products VALUES("60","Cargo Bill2","50827698","standard","C128","","2","7","7","7","5.7","6","1","1","","","","","","","","zummXD2dvAtI.png","","","","","","","","","","","","","","","1","2023-04-19 14:28:47","2023-04-19 14:31:18","","","");
INSERT INTO products VALUES("61","NESTLE MILKYBAR COOKIES &amp; CREAM 09/23","7613039023488","standard","C128","","1","1","1","1","0.75","1.5","100","","","","","2023-04-24","","","1","zummXD2dvAtI.png","","","","1","","","","","","","","","","","1","2023-04-24 16:04:32","2023-04-24 16:06:29","","0.90","0.90");
INSERT INTO products VALUES("62","Test","39503261","standard","C128","","2","1","1","1","5.7","6.3","0","20","","","","","","","1","zummXD2dvAtI.png","","","","","","","","","","","","<p>Test&nbsp;</p>","","","0","2023-05-01 16:20:25","2023-05-02 16:18:18","The first option is easy and will work if your theme offers this functionality.","20.00","20.00");
INSERT INTO products VALUES("63","Test 22","80073358","standard","C128","19","1","1","1","1","123","124","9","1","","","","","","","1","zummXD2dvAtI.png","","","","1","","","","","","","","","","","0","2023-05-02 14:39:28","2023-05-02 16:18:18","","1.00","1.50");



CREATE TABLE `purchase_product_return` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `return_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `product_batch_id` int(11) DEFAULT NULL,
  `variant_id` int(11) DEFAULT NULL,
  `imei_number` text COLLATE utf8mb4_unicode_ci,
  `qty` double NOT NULL,
  `purchase_unit_id` int(11) NOT NULL,
  `net_unit_cost` double NOT NULL,
  `discount` double NOT NULL,
  `tax_rate` double NOT NULL,
  `tax` double NOT NULL,
  `total` double NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;




CREATE TABLE `purchases` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `reference_no` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` int(11) NOT NULL,
  `warehouse_id` int(11) NOT NULL,
  `supplier_id` int(11) DEFAULT NULL,
  `item` int(11) NOT NULL,
  `total_qty` double NOT NULL,
  `total_discount` double NOT NULL,
  `total_tax` double NOT NULL,
  `total_cost` double NOT NULL,
  `order_tax_rate` double DEFAULT NULL,
  `order_tax` double DEFAULT NULL,
  `order_discount` double DEFAULT NULL,
  `shipping_cost` double DEFAULT NULL,
  `grand_total` double NOT NULL,
  `paid_amount` double NOT NULL,
  `status` int(11) NOT NULL,
  `payment_status` int(11) NOT NULL,
  `document` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `note` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=71 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO purchases VALUES("50","pr-20230403-115613","1","1","17","1","1","0","0","1368.04","0","0","","","1368.04","0","1","1","","","2023-04-16 00:00:00","2023-04-03 11:56:13");
INSERT INTO purchases VALUES("63","pr-20230412-114056","1","1","28","1","322","0","0","1803.2","0","0","","","1803.2","0","1","1","","","2023-04-12 00:00:00","2023-04-12 11:40:56");
INSERT INTO purchases VALUES("64","pr-20230417-121414","1","1","28","1","317","0","0","1775.2","0","0","","","1775.2","0","1","1","","DUE","2023-04-17 00:00:00","2023-04-17 12:14:14");
INSERT INTO purchases VALUES("65","pr-20230419-022848","1","1","26","1","1","0","0","5.7","","","","","5.7","0","1","1","","","2023-04-19 14:28:48","");
INSERT INTO purchases VALUES("66","pr-20230419-022959","1","1","26","1","272","0","0","1550.4","0","0","","","1550.4","0","1","1","","","2023-04-19 00:00:00","2023-04-19 14:29:59");
INSERT INTO purchases VALUES("67","pr-20230424-112419","1","1","28","1","1000","0","0","5600","0","0","","","5600","0","1","1","","","2023-04-17 00:00:00","2023-04-24 11:24:19");
INSERT INTO purchases VALUES("68","pr-20230424-040629","43","2","26","1","100","0","0","75","0","0","","","75","0","1","1","","","2023-04-24 00:00:00","2023-04-24 16:06:29");
INSERT INTO purchases VALUES("69","pr-20230501-042112","1","1","28","1","1","0","0","5.7","0","0","","","5.7","0","1","1","","","2023-05-01 00:00:00","2023-05-01 16:21:12");
INSERT INTO purchases VALUES("70","pr-20230502-024058","1","1","20","1","10","0","0","1230","0","0","","","1230","0","1","1","","","2023-05-02 00:00:00","2023-05-02 14:40:58");



CREATE TABLE `quotations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `reference_no` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` int(11) NOT NULL,
  `biller_id` int(11) NOT NULL,
  `supplier_id` int(11) DEFAULT NULL,
  `customer_id` int(11) NOT NULL,
  `warehouse_id` int(11) NOT NULL,
  `item` int(11) NOT NULL,
  `total_qty` double NOT NULL,
  `total_discount` double NOT NULL,
  `total_tax` double NOT NULL,
  `total_price` double NOT NULL,
  `order_tax_rate` double DEFAULT NULL,
  `order_tax` double DEFAULT NULL,
  `order_discount` double DEFAULT NULL,
  `shipping_cost` double DEFAULT NULL,
  `grand_total` double NOT NULL,
  `quotation_status` int(11) NOT NULL,
  `document` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `note` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO quotations VALUES("1","qr-20230329-033402","1","11","15","3","1","1","1","0","0","1007.12","0","0","","","1007.12","1","","","2023-03-29 15:34:02","2023-03-29 15:34:02");
INSERT INTO quotations VALUES("2","qr-20230329-033944","1","10","15","2","1","1","1","0","0","1007.12","0","0","","","1007.12","1","","","2023-03-29 15:39:44","2023-03-29 15:39:44");



CREATE TABLE `return_purchases` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `reference_no` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `supplier_id` int(11) DEFAULT NULL,
  `warehouse_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `purchase_id` int(11) DEFAULT NULL,
  `account_id` int(11) NOT NULL,
  `item` int(11) NOT NULL,
  `total_qty` double NOT NULL,
  `total_discount` double NOT NULL,
  `total_tax` double NOT NULL,
  `total_cost` double NOT NULL,
  `order_tax_rate` double DEFAULT NULL,
  `order_tax` double DEFAULT NULL,
  `grand_total` double NOT NULL,
  `document` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `return_note` text COLLATE utf8mb4_unicode_ci,
  `staff_note` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;




CREATE TABLE `returns` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `reference_no` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` int(11) NOT NULL,
  `sale_id` int(11) DEFAULT NULL,
  `cash_register_id` int(11) DEFAULT NULL,
  `customer_id` int(11) NOT NULL,
  `warehouse_id` int(11) NOT NULL,
  `biller_id` int(11) NOT NULL,
  `account_id` int(11) NOT NULL,
  `item` int(11) NOT NULL,
  `total_qty` double NOT NULL,
  `total_discount` double NOT NULL,
  `total_tax` double NOT NULL,
  `total_price` double NOT NULL,
  `order_tax_rate` double DEFAULT NULL,
  `order_tax` double DEFAULT NULL,
  `grand_total` double NOT NULL,
  `document` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `return_note` text COLLATE utf8mb4_unicode_ci,
  `staff_note` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;




CREATE TABLE `reward_point_settings` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `per_point_amount` double NOT NULL,
  `minimum_amount` double NOT NULL,
  `duration` int(11) DEFAULT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO reward_point_settings VALUES("1","300","1000","1","Year","1","2021-06-08 08:40:15","2021-06-26 22:20:55");



CREATE TABLE `role_has_permissions` (
  `permission_id` int(10) unsigned NOT NULL,
  `role_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`role_id`),
  KEY `role_has_permissions_role_id_foreign` (`role_id`),
  CONSTRAINT `role_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `role_has_permissions_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO role_has_permissions VALUES("4","1");
INSERT INTO role_has_permissions VALUES("5","1");
INSERT INTO role_has_permissions VALUES("6","1");
INSERT INTO role_has_permissions VALUES("7","1");
INSERT INTO role_has_permissions VALUES("8","1");
INSERT INTO role_has_permissions VALUES("9","1");
INSERT INTO role_has_permissions VALUES("10","1");
INSERT INTO role_has_permissions VALUES("11","1");
INSERT INTO role_has_permissions VALUES("12","1");
INSERT INTO role_has_permissions VALUES("13","1");
INSERT INTO role_has_permissions VALUES("14","1");
INSERT INTO role_has_permissions VALUES("15","1");
INSERT INTO role_has_permissions VALUES("16","1");
INSERT INTO role_has_permissions VALUES("17","1");
INSERT INTO role_has_permissions VALUES("18","1");
INSERT INTO role_has_permissions VALUES("19","1");
INSERT INTO role_has_permissions VALUES("20","1");
INSERT INTO role_has_permissions VALUES("21","1");
INSERT INTO role_has_permissions VALUES("22","1");
INSERT INTO role_has_permissions VALUES("23","1");
INSERT INTO role_has_permissions VALUES("24","1");
INSERT INTO role_has_permissions VALUES("25","1");
INSERT INTO role_has_permissions VALUES("26","1");
INSERT INTO role_has_permissions VALUES("27","1");
INSERT INTO role_has_permissions VALUES("28","1");
INSERT INTO role_has_permissions VALUES("29","1");
INSERT INTO role_has_permissions VALUES("30","1");
INSERT INTO role_has_permissions VALUES("31","1");
INSERT INTO role_has_permissions VALUES("32","1");
INSERT INTO role_has_permissions VALUES("33","1");
INSERT INTO role_has_permissions VALUES("34","1");
INSERT INTO role_has_permissions VALUES("35","1");
INSERT INTO role_has_permissions VALUES("36","1");
INSERT INTO role_has_permissions VALUES("37","1");
INSERT INTO role_has_permissions VALUES("38","1");
INSERT INTO role_has_permissions VALUES("39","1");
INSERT INTO role_has_permissions VALUES("40","1");
INSERT INTO role_has_permissions VALUES("41","1");
INSERT INTO role_has_permissions VALUES("42","1");
INSERT INTO role_has_permissions VALUES("43","1");
INSERT INTO role_has_permissions VALUES("44","1");
INSERT INTO role_has_permissions VALUES("45","1");
INSERT INTO role_has_permissions VALUES("46","1");
INSERT INTO role_has_permissions VALUES("47","1");
INSERT INTO role_has_permissions VALUES("48","1");
INSERT INTO role_has_permissions VALUES("49","1");
INSERT INTO role_has_permissions VALUES("50","1");
INSERT INTO role_has_permissions VALUES("51","1");
INSERT INTO role_has_permissions VALUES("52","1");
INSERT INTO role_has_permissions VALUES("53","1");
INSERT INTO role_has_permissions VALUES("54","1");
INSERT INTO role_has_permissions VALUES("55","1");
INSERT INTO role_has_permissions VALUES("56","1");
INSERT INTO role_has_permissions VALUES("57","1");
INSERT INTO role_has_permissions VALUES("58","1");
INSERT INTO role_has_permissions VALUES("59","1");
INSERT INTO role_has_permissions VALUES("60","1");
INSERT INTO role_has_permissions VALUES("61","1");
INSERT INTO role_has_permissions VALUES("62","1");
INSERT INTO role_has_permissions VALUES("63","1");
INSERT INTO role_has_permissions VALUES("64","1");
INSERT INTO role_has_permissions VALUES("65","1");
INSERT INTO role_has_permissions VALUES("66","1");
INSERT INTO role_has_permissions VALUES("67","1");
INSERT INTO role_has_permissions VALUES("68","1");
INSERT INTO role_has_permissions VALUES("69","1");
INSERT INTO role_has_permissions VALUES("70","1");
INSERT INTO role_has_permissions VALUES("71","1");
INSERT INTO role_has_permissions VALUES("72","1");
INSERT INTO role_has_permissions VALUES("73","1");
INSERT INTO role_has_permissions VALUES("74","1");
INSERT INTO role_has_permissions VALUES("75","1");
INSERT INTO role_has_permissions VALUES("76","1");
INSERT INTO role_has_permissions VALUES("77","1");
INSERT INTO role_has_permissions VALUES("78","1");
INSERT INTO role_has_permissions VALUES("79","1");
INSERT INTO role_has_permissions VALUES("80","1");
INSERT INTO role_has_permissions VALUES("81","1");
INSERT INTO role_has_permissions VALUES("82","1");
INSERT INTO role_has_permissions VALUES("83","1");
INSERT INTO role_has_permissions VALUES("84","1");
INSERT INTO role_has_permissions VALUES("85","1");
INSERT INTO role_has_permissions VALUES("86","1");
INSERT INTO role_has_permissions VALUES("87","1");
INSERT INTO role_has_permissions VALUES("88","1");
INSERT INTO role_has_permissions VALUES("89","1");
INSERT INTO role_has_permissions VALUES("90","1");
INSERT INTO role_has_permissions VALUES("91","1");
INSERT INTO role_has_permissions VALUES("92","1");
INSERT INTO role_has_permissions VALUES("93","1");
INSERT INTO role_has_permissions VALUES("94","1");
INSERT INTO role_has_permissions VALUES("95","1");
INSERT INTO role_has_permissions VALUES("96","1");
INSERT INTO role_has_permissions VALUES("97","1");
INSERT INTO role_has_permissions VALUES("98","1");
INSERT INTO role_has_permissions VALUES("99","1");
INSERT INTO role_has_permissions VALUES("100","1");
INSERT INTO role_has_permissions VALUES("101","1");
INSERT INTO role_has_permissions VALUES("102","1");
INSERT INTO role_has_permissions VALUES("103","1");
INSERT INTO role_has_permissions VALUES("104","1");
INSERT INTO role_has_permissions VALUES("105","1");
INSERT INTO role_has_permissions VALUES("106","1");
INSERT INTO role_has_permissions VALUES("107","1");
INSERT INTO role_has_permissions VALUES("108","1");
INSERT INTO role_has_permissions VALUES("109","1");
INSERT INTO role_has_permissions VALUES("110","1");
INSERT INTO role_has_permissions VALUES("111","1");
INSERT INTO role_has_permissions VALUES("112","1");
INSERT INTO role_has_permissions VALUES("113","1");
INSERT INTO role_has_permissions VALUES("114","1");
INSERT INTO role_has_permissions VALUES("115","1");
INSERT INTO role_has_permissions VALUES("116","1");
INSERT INTO role_has_permissions VALUES("117","1");
INSERT INTO role_has_permissions VALUES("118","1");
INSERT INTO role_has_permissions VALUES("119","1");
INSERT INTO role_has_permissions VALUES("120","1");
INSERT INTO role_has_permissions VALUES("121","1");
INSERT INTO role_has_permissions VALUES("122","1");
INSERT INTO role_has_permissions VALUES("123","1");
INSERT INTO role_has_permissions VALUES("124","1");
INSERT INTO role_has_permissions VALUES("125","1");
INSERT INTO role_has_permissions VALUES("4","2");
INSERT INTO role_has_permissions VALUES("5","2");
INSERT INTO role_has_permissions VALUES("6","2");
INSERT INTO role_has_permissions VALUES("7","2");
INSERT INTO role_has_permissions VALUES("8","2");
INSERT INTO role_has_permissions VALUES("9","2");
INSERT INTO role_has_permissions VALUES("10","2");
INSERT INTO role_has_permissions VALUES("11","2");
INSERT INTO role_has_permissions VALUES("12","2");
INSERT INTO role_has_permissions VALUES("13","2");
INSERT INTO role_has_permissions VALUES("14","2");
INSERT INTO role_has_permissions VALUES("15","2");
INSERT INTO role_has_permissions VALUES("16","2");
INSERT INTO role_has_permissions VALUES("17","2");
INSERT INTO role_has_permissions VALUES("18","2");
INSERT INTO role_has_permissions VALUES("19","2");
INSERT INTO role_has_permissions VALUES("20","2");
INSERT INTO role_has_permissions VALUES("21","2");
INSERT INTO role_has_permissions VALUES("22","2");
INSERT INTO role_has_permissions VALUES("23","2");
INSERT INTO role_has_permissions VALUES("24","2");
INSERT INTO role_has_permissions VALUES("25","2");
INSERT INTO role_has_permissions VALUES("26","2");
INSERT INTO role_has_permissions VALUES("27","2");
INSERT INTO role_has_permissions VALUES("28","2");
INSERT INTO role_has_permissions VALUES("29","2");
INSERT INTO role_has_permissions VALUES("30","2");
INSERT INTO role_has_permissions VALUES("31","2");
INSERT INTO role_has_permissions VALUES("32","2");
INSERT INTO role_has_permissions VALUES("33","2");
INSERT INTO role_has_permissions VALUES("34","2");
INSERT INTO role_has_permissions VALUES("35","2");
INSERT INTO role_has_permissions VALUES("36","2");
INSERT INTO role_has_permissions VALUES("37","2");
INSERT INTO role_has_permissions VALUES("38","2");
INSERT INTO role_has_permissions VALUES("39","2");
INSERT INTO role_has_permissions VALUES("40","2");
INSERT INTO role_has_permissions VALUES("41","2");
INSERT INTO role_has_permissions VALUES("42","2");
INSERT INTO role_has_permissions VALUES("43","2");
INSERT INTO role_has_permissions VALUES("44","2");
INSERT INTO role_has_permissions VALUES("45","2");
INSERT INTO role_has_permissions VALUES("46","2");
INSERT INTO role_has_permissions VALUES("47","2");
INSERT INTO role_has_permissions VALUES("48","2");
INSERT INTO role_has_permissions VALUES("49","2");
INSERT INTO role_has_permissions VALUES("50","2");
INSERT INTO role_has_permissions VALUES("51","2");
INSERT INTO role_has_permissions VALUES("52","2");
INSERT INTO role_has_permissions VALUES("53","2");
INSERT INTO role_has_permissions VALUES("54","2");
INSERT INTO role_has_permissions VALUES("55","2");
INSERT INTO role_has_permissions VALUES("56","2");
INSERT INTO role_has_permissions VALUES("57","2");
INSERT INTO role_has_permissions VALUES("58","2");
INSERT INTO role_has_permissions VALUES("59","2");
INSERT INTO role_has_permissions VALUES("60","2");
INSERT INTO role_has_permissions VALUES("61","2");
INSERT INTO role_has_permissions VALUES("62","2");
INSERT INTO role_has_permissions VALUES("63","2");
INSERT INTO role_has_permissions VALUES("64","2");
INSERT INTO role_has_permissions VALUES("65","2");
INSERT INTO role_has_permissions VALUES("66","2");
INSERT INTO role_has_permissions VALUES("67","2");
INSERT INTO role_has_permissions VALUES("68","2");
INSERT INTO role_has_permissions VALUES("69","2");
INSERT INTO role_has_permissions VALUES("70","2");
INSERT INTO role_has_permissions VALUES("71","2");
INSERT INTO role_has_permissions VALUES("72","2");
INSERT INTO role_has_permissions VALUES("73","2");
INSERT INTO role_has_permissions VALUES("74","2");
INSERT INTO role_has_permissions VALUES("75","2");
INSERT INTO role_has_permissions VALUES("76","2");
INSERT INTO role_has_permissions VALUES("77","2");
INSERT INTO role_has_permissions VALUES("78","2");
INSERT INTO role_has_permissions VALUES("79","2");
INSERT INTO role_has_permissions VALUES("80","2");
INSERT INTO role_has_permissions VALUES("81","2");
INSERT INTO role_has_permissions VALUES("82","2");
INSERT INTO role_has_permissions VALUES("83","2");
INSERT INTO role_has_permissions VALUES("84","2");
INSERT INTO role_has_permissions VALUES("85","2");
INSERT INTO role_has_permissions VALUES("86","2");
INSERT INTO role_has_permissions VALUES("87","2");
INSERT INTO role_has_permissions VALUES("88","2");
INSERT INTO role_has_permissions VALUES("89","2");
INSERT INTO role_has_permissions VALUES("90","2");
INSERT INTO role_has_permissions VALUES("91","2");
INSERT INTO role_has_permissions VALUES("92","2");
INSERT INTO role_has_permissions VALUES("93","2");
INSERT INTO role_has_permissions VALUES("94","2");
INSERT INTO role_has_permissions VALUES("95","2");
INSERT INTO role_has_permissions VALUES("96","2");
INSERT INTO role_has_permissions VALUES("97","2");
INSERT INTO role_has_permissions VALUES("98","2");
INSERT INTO role_has_permissions VALUES("99","2");
INSERT INTO role_has_permissions VALUES("100","2");
INSERT INTO role_has_permissions VALUES("101","2");
INSERT INTO role_has_permissions VALUES("102","2");
INSERT INTO role_has_permissions VALUES("103","2");
INSERT INTO role_has_permissions VALUES("104","2");
INSERT INTO role_has_permissions VALUES("105","2");
INSERT INTO role_has_permissions VALUES("4","4");
INSERT INTO role_has_permissions VALUES("6","4");
INSERT INTO role_has_permissions VALUES("7","4");
INSERT INTO role_has_permissions VALUES("8","4");
INSERT INTO role_has_permissions VALUES("9","4");
INSERT INTO role_has_permissions VALUES("12","4");
INSERT INTO role_has_permissions VALUES("13","4");
INSERT INTO role_has_permissions VALUES("20","4");
INSERT INTO role_has_permissions VALUES("21","4");
INSERT INTO role_has_permissions VALUES("22","4");
INSERT INTO role_has_permissions VALUES("24","4");
INSERT INTO role_has_permissions VALUES("25","4");
INSERT INTO role_has_permissions VALUES("28","4");
INSERT INTO role_has_permissions VALUES("29","4");
INSERT INTO role_has_permissions VALUES("55","4");
INSERT INTO role_has_permissions VALUES("56","4");
INSERT INTO role_has_permissions VALUES("57","4");
INSERT INTO role_has_permissions VALUES("63","4");
INSERT INTO role_has_permissions VALUES("64","4");



CREATE TABLE `roles` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `guard_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO roles VALUES("1","Super Admin","admin can access all data...","web","1","2018-06-01 16:46:44","2023-03-22 09:06:36");
INSERT INTO roles VALUES("2","Admin","Staff of shop","web","1","2018-10-21 19:38:13","2023-03-22 09:06:46");
INSERT INTO roles VALUES("4","Staff","staff has specific acess...","web","1","2018-06-01 17:05:27","2023-03-22 09:06:55");
INSERT INTO roles VALUES("5","Customer","","web","1","2020-11-04 23:43:16","2020-11-14 17:24:15");



CREATE TABLE `sales` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `reference_no` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` int(11) NOT NULL,
  `cash_register_id` int(11) DEFAULT NULL,
  `customer_id` int(11) NOT NULL,
  `warehouse_id` int(11) NOT NULL,
  `biller_id` int(11) DEFAULT NULL,
  `item` int(11) NOT NULL,
  `total_qty` double NOT NULL,
  `total_discount` double NOT NULL,
  `total_tax` double NOT NULL,
  `total_price` double NOT NULL,
  `currency_id` int(11) NOT NULL,
  `grand_total` double NOT NULL,
  `pickup_cost` double(20,2) DEFAULT NULL,
  `delivery_cost` double(20,2) DEFAULT NULL,
  `packaging_cost` double(20,2) DEFAULT NULL,
  `bd_charges_cost` double(20,2) DEFAULT NULL,
  `order_tax_rate` double DEFAULT NULL,
  `order_tax` double DEFAULT NULL,
  `order_discount_type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `order_discount_value` double DEFAULT NULL,
  `order_discount` double DEFAULT NULL,
  `coupon_id` int(11) DEFAULT NULL,
  `coupon_discount` double DEFAULT NULL,
  `shipping_cost` double DEFAULT NULL,
  `sale_status` int(11) NOT NULL,
  `payment_status` int(11) NOT NULL,
  `document` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `paid_amount` double DEFAULT NULL,
  `sale_note` text COLLATE utf8mb4_unicode_ci,
  `staff_note` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=84 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO sales VALUES("57","BCP216223","1","7","3","1","10","1","1","0","0","1573.2","1","1573.2","","","","","0","0","Flat","","0","","","","1","1","","","","","2023-04-16 00:00:00","2023-04-03 12:59:34");
INSERT INTO sales VALUES("73","sr-20230410-104812","1","7","13","1","13","1","322","0","0","2044.7","1","2043.43","","","","","0","0","Flat","","1.27","","","0","1","2","","","Chocolate, Cosmetics
Total 321.80kg","","2023-04-07 00:00:00","2023-04-12 11:32:52");
INSERT INTO sales VALUES("74","LIT-123456","1","7","13","1","10","1","1","0","0","6.35","1","15.35","2.50","2.00","1.50","1.50","0","0","Flat","","0","","","1.5","1","2","","","Test Note","Test Note 2","2023-04-10 00:00:00","2023-04-10 12:33:48");
INSERT INTO sales VALUES("75","01022023","1","7","13","1","13","1","322","0","0","2044.7","1","1925.23","10.00","15.00","50.00","10.00","0","0","Percentage","10","204.47000000000003","","","","1","4","","1925.23","","","2023-04-12 00:00:00","2023-04-12 11:43:13");
INSERT INTO sales VALUES("76","17042023","1","7","13","1","13","1","334","0","0","2120.9","1","2117.41","","","","","0","0","Flat","3.49","3.49","","","0","1","2","","","","","2023-04-17 00:00:00","2023-04-24 11:25:42");
INSERT INTO sales VALUES("77","AMBS1-14","1","7","14","1","14","1","272","0","0","1632","1","1702","","","70.00","","0","0","Flat","","0","","","","1","1","","","Due","","2023-04-19 00:00:00","2023-04-19 14:31:18");
INSERT INTO sales VALUES("78","sr-20230424-041102","43","9","14","2","15","1","50","0","0","75","3","88","","10.00","3.00","5.00","0","0","Flat","","5","","","0","2","2","","","","","2023-04-24 00:00:00","2023-04-24 16:13:06");
INSERT INTO sales VALUES("82","sr-20230502-022859","1","7","13","1","10","1","1","0","0","6.3","1","6.3","","","","","0","0","Flat","","0","","","","1","1","","","","","2023-05-02 00:00:00","2023-05-02 14:28:59");
INSERT INTO sales VALUES("83","sfgsdfgwe","1","7","13","1","10","1","1","0","0","124","1","124","","","","","0","0","Flat","","0","","","","1","1","","","","","2023-05-02 00:00:00","2023-05-02 14:41:41");



CREATE TABLE `stock_counts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `reference_no` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `warehouse_id` int(11) NOT NULL,
  `category_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `brand_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `initial_file` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `final_file` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `note` text COLLATE utf8mb4_unicode_ci,
  `is_adjusted` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;




CREATE TABLE `suppliers` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `company_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `vat_number` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone_number` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `city` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `state` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `postal_code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `country` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO suppliers VALUES("1","abdullah","globaltouch.jpg","global touch","","abdullah@gmail.com","231231","fsdfs","fsdfs","","","bd","0","2018-05-12 15:06:34","2023-03-17 17:13:46");
INSERT INTO suppliers VALUES("2","test","lion.jpg","lion","","lion@gmail.com","242","gfdg","fgd","","","","0","2018-05-29 16:59:41","2018-05-29 17:00:06");
INSERT INTO suppliers VALUES("3","ismail","","techbd","","ismail@test.com","23123123","mohammadpur","dhaka","","","bangladesh","0","2018-07-19 21:34:17","2023-03-17 17:13:46");
INSERT INTO suppliers VALUES("4","modon","mogaFruit.jpg","mogaFruit","","modon@gmail.com","32321","nasirabad","chittagong","","","bd","0","2018-08-31 21:30:07","2018-08-31 21:37:20");
INSERT INTO suppliers VALUES("5","sadman","","anda boda","dsa","asd@dsa.com","3212313","dadas","sdad","Other","1312","Australia","0","2020-06-22 02:48:33","2020-06-22 02:48:52");
INSERT INTO suppliers VALUES("11","Ayon","","Largeit","","ayat.com@gmail.com","123456789","Dhaka","Dhaka","","","","0","2023-03-17 17:05:54","2023-03-17 17:13:46");
INSERT INTO suppliers VALUES("12","Raduan islam","","Largeit","","raduan.cse@gmail.com","123456789","Dhaka","Dhaka","","","Bangladesh","0","2023-03-17 17:24:58","2023-03-21 18:14:26");
INSERT INTO suppliers VALUES("13","LR direct","FourtrackLogisticsLtd.png","Fourtrack Logistics Ltd","GB176589157","customerservices@lrdirect.com","0330 808 2053","Unit 9F Centurion Court Leyland","UK","","PR25 3UQ","","0","2023-03-21 17:55:43","2023-04-10 13:35:35");
INSERT INTO suppliers VALUES("14","Parts Gateaway","PartsGateAway.jpeg","Parts GateAway","","quotes@partsgateway.co.uk","n/a","uk","london","","","","0","2023-03-21 17:58:54","2023-04-10 13:35:35");
INSERT INTO suppliers VALUES("15","GRANGE WOODFORD","LANDROVER.png","LAND ROVER","","alison.winter@grange.co.uk","02085007024","HAINAULT","HAINAULT","","","","0","2023-03-21 18:01:54","2023-04-10 13:35:35");
INSERT INTO suppliers VALUES("16","Endeavour Automotive Ltd","EndeavourAutomotiveLtd.jpeg","Endeavour Automotive Ltd","","Steven.Evans@endeavourautomotive.co.uk","0203 871 9915","Edgware Road, Colindale, United Kingdom, NW9 6NW","Edgware Road, Colindale, United Kingdom, NW9 6NW","","","","0","2023-03-21 18:04:53","2023-04-10 13:35:35");
INSERT INTO suppliers VALUES("17","Caffyns Volvo Eastbourne","CaffynsVolvoEastbourne.jpeg","Caffyns Volvo Eastbourne","","chris.gander@caffyns.co.uk","01903 441576","Caffyns Volvo Eastbourne 46 Lottbridge Drove Eastbourne East Sussex BN23 6PJ","East Sussex,","","","","0","2023-03-21 18:07:26","2023-04-10 13:35:35");
INSERT INTO suppliers VALUES("18","BMW","AboutSytnerChigwell.jpeg","About Sytner Chigwell","","kenneththurlow@sytner.co.uk","02081314944","Langston Road  Loughton  Essex  IG10 3UE","LOUGHTON","","","","0","2023-03-21 18:12:00","2023-04-10 13:35:35");
INSERT INTO suppliers VALUES("19","PAUL","MERCEDEZBENZ.jpeg","MERCEDEZ BENZ","","paulbutler@sytner.co.uk","02082051212","EDGWARE ROAD","LONDON","","","","0","2023-03-21 18:22:17","2023-04-10 13:35:35");
INSERT INTO suppliers VALUES("20","EBAY","EBAY.png","EBAY","","NA@GMAIL.COM","NA","UK","LONDON","","","","1","2023-03-21 18:23:58","2023-03-21 18:23:58");
INSERT INTO suppliers VALUES("21","Harold Wood Audi","HaroldWoodAudi.png","Harold Wood Audi","","steveeastman@haroldwood-audi.co.uk","01708 330 725","HAROLDWOOD","HAROLDWOOD","","","","0","2023-03-21 18:25:43","2023-04-10 13:35:35");
INSERT INTO suppliers VALUES("22","LLL PARTS","LLLPARTS.png","LLL PARTS","","support@lllparts.co.uk","NA","148 High Street South, East Ham, London, E6 3RW, United Kingdom","148 High Street South, East Ham, London, E6 3RW, United Kingdom","","","","0","2023-03-21 18:27:51","2023-04-10 13:35:35");
INSERT INTO suppliers VALUES("23","RIMMERS BROS","RIMMERSBROS.png","RIMMERS BROS","","lrsales@rimmerbros.com","01522 568000","Rimmer Bros., Triumph House, Sleaford Road, Bracebridge Heath, Lincoln. LN4 2NA.","Rimmer Bros., Triumph House, Sleaford Road, Bracebridge Heath, Lincoln. LN4 2NA.","","","","0","2023-03-21 18:31:03","2023-04-10 13:38:48");
INSERT INTO suppliers VALUES("24","GLYN HOPKIN","GLYNHOPKIN.png","GLYN HOPKIN","","parts.eastlondon@glynhopkin.com","020 8131 2733","1021 Romford Rd, London E12 5LH","1021 Romford Rd, London E12 5LH","","","","0","2023-03-21 18:42:55","2023-04-10 13:38:48");
INSERT INTO suppliers VALUES("25","BENTLY","BENTLY.jpeg","BENTLY","","Hitesh.Patel@hrowen.co.uk","01707 247190","UK","UK","","","","0","2023-03-21 18:44:21","2023-04-10 13:38:48");
INSERT INTO suppliers VALUES("26","LOCAL PURCHASE","LOCALPURCHASE.jpeg","LOCAL PURCHASE","","info@banglacarparts.com","07739371171","Unit 6","Ilford","Essex","IG1 4Bl","United Kingdom","1","2023-03-21 18:45:13","2023-03-21 18:45:13");
INSERT INTO suppliers VALUES("27","SIBBIR AHMED","BograMotorsUKLimited.png","Bogra Motors UK Limited","","bogramotorsuk@gmail.com","020 3876 5688","125 Ley Street  Ilford  IG1 4BH","ILFORD","","IG1 4BH","UK","0","2023-03-21 19:11:12","2023-04-10 13:38:48");
INSERT INTO suppliers VALUES("28","Mithu vai","Mithuvai.jpeg","Mithu vai","","ambsglobaluk@gmail.com","0000","ilford","ilford","Essex","IG1 4sl","United Kingdom","1","2023-04-10 13:40:05","2023-04-10 13:40:05");



CREATE TABLE `taxes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `rate` double NOT NULL,
  `is_active` tinyint(1) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO taxes VALUES("1","vat@10","10","1","2018-05-12 02:58:30","2019-03-02 04:46:10");
INSERT INTO taxes VALUES("2","vat@15","15","1","2018-05-12 02:58:43","2018-05-27 16:35:05");
INSERT INTO taxes VALUES("3","test","6","0","2018-05-27 16:32:54","2018-05-27 16:34:44");
INSERT INTO taxes VALUES("4","vat 20","20","1","2018-08-31 17:58:57","2018-08-31 17:58:57");



CREATE TABLE `transfers` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `reference_no` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `from_warehouse_id` int(11) NOT NULL,
  `to_warehouse_id` int(11) NOT NULL,
  `item` int(11) NOT NULL,
  `total_qty` double NOT NULL,
  `total_tax` double NOT NULL,
  `total_cost` double NOT NULL,
  `shipping_cost` double DEFAULT NULL,
  `grand_total` double NOT NULL,
  `document` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `note` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;




CREATE TABLE `units` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `unit_code` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `unit_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `base_unit` int(11) DEFAULT NULL,
  `operator` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `operation_value` double DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO units VALUES("1","pc","Piece","","*","1","1","2018-05-11 19:27:46","2018-08-17 14:41:53");
INSERT INTO units VALUES("2","dozen","dozen box","1","*","12","1","2018-05-12 02:57:05","2018-05-12 02:57:05");
INSERT INTO units VALUES("3","cartoon","cartoon box","1","*","50","1","2018-05-12 02:57:45","2022-06-07 03:37:11");
INSERT INTO units VALUES("4","m","meter","","*","1","1","2018-05-12 02:58:07","2018-05-27 16:20:57");
INSERT INTO units VALUES("6","test","test","","*","1","0","2018-05-27 16:20:20","2018-05-27 16:20:25");
INSERT INTO units VALUES("7","kg","kilogram","","*","1","1","2018-06-24 17:49:26","2018-06-24 17:49:26");
INSERT INTO units VALUES("8","20","ni33","8","*","1","0","2018-07-31 15:35:51","2018-07-31 15:40:54");
INSERT INTO units VALUES("9","gm","gram","7","/","1000","1","2018-08-31 17:06:28","2018-08-31 17:06:28");
INSERT INTO units VALUES("10","gz","goz","","*","1","0","2018-11-28 20:40:29","2019-03-02 04:53:29");
INSERT INTO units VALUES("11","inch","Inch","","*","1","1","2022-06-07 03:42:40","2022-06-07 03:42:40");



CREATE TABLE `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `company_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `role_id` int(11) NOT NULL,
  `biller_id` int(11) DEFAULT NULL,
  `warehouse_id` int(11) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL,
  `is_deleted` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO users VALUES("1","superadmin","info@banglacarparts.com","$2y$10$5S1GtMuLiB1cOvSgmkb.w.o/hxOoL8zyK3BEtSeMmRtq0pt2GLaey","ClXhwn4gzAYF1K0jLIx25uJykMXLzNhrZJPZz1H3Z6RwXj0mIssu2RF4Er9O","123456789","Large it","1","","","1","0","2018-06-01 20:24:15","2023-04-06 08:09:32");
INSERT INTO users VALUES("3","dhiman da","dhiman@gmail.com","$2y$10$Fef6vu5E67nm11hX7V5a2u1ThNCQ6n9DRCvRF9TD7stk.Pmt2R6O.","5ehQM6JIfiQfROgTbB5let0Z93vjLHS7rd9QD5RPNgOxli3xdo7fykU7vtTt","212","lioncoders","1","","","0","1","2018-06-13 15:00:31","2020-11-05 00:06:51");
INSERT INTO users VALUES("6","test","test@gmail.com","$2y$10$TDAeHcVqHyCmurki0wjLZeIl1SngKX3WLOhyTiCoZG3souQfqv.LS","KpW1gYYlOFacumklO2IcRfSsbC3KcWUZzOI37gqoqM388Xie6KdhaOHIFEYm","1234","212312","4","","","0","1","2018-06-22 20:05:33","2018-06-22 20:13:45");
INSERT INTO users VALUES("8","test","test@yahoo.com","$2y$10$hlMigidZV0j2/IPkgE/xsOSb8WM2IRlsMv.1hg1NM7kfyd6bGX3hC","","31231","","4","","","0","1","2018-06-24 15:35:49","2018-07-01 18:07:39");
INSERT INTO users VALUES("9","staff","anda@gmail.com","$2y$10$kxDbnynB6mB1e1w3pmtbSOlSxy/WwbLPY5TJpMi0Opao5ezfuQjQm","rplfWUMkhycFaSTaHdn2ISb1dEhdyI5qchjECtCZpq6OqlPwu6O9Xvm7xatz","3123","","4","5","1","0","1","2018-07-01 18:08:08","2023-03-21 23:01:24");
INSERT INTO users VALUES("10","abul","abul@alpha.com","$2y$10$5zgB2OOMyNBNVAd.QOQIju5a9fhNnTqPx5H6s4oFlXhNiF6kXEsPq","x7HlttI5bM0vSKViqATaowHFJkLS3PHwfvl7iJdFl5Z1SsyUgWCVbLSgAoi0","1234","anda","1","","","0","1","2018-09-07 16:44:48","2023-03-17 17:11:29");
INSERT INTO users VALUES("11","teststaff","a@a.com","$2y$10$5KNBIIhZzvvZEQEhkHaZGu.Q8bbQNfqYvYgL5N55B8Pb4P5P/b/Li","DkHDEcCA0QLfsKPkUK0ckL0CPM6dPiJytNa0k952gyTbeAyMthW3vi7IRitp","111","aa","4","5","1","0","1","2018-10-21 19:47:56","2018-10-22 19:10:56");
INSERT INTO users VALUES("12","john","john@gmail.com","$2y$10$P/pN2J/uyTYNzQy2kRqWwuSv7P2f6GE/ykBwtHdda7yci3XsfOKWe","O0f1WJBVjT5eKYl3Js5l1ixMMtoU6kqrH7hbHDx9I1UCcD9CmiSmCBzHbQZg","10001","","4","2","2","0","1","2018-12-29 17:48:37","2019-03-05 21:59:49");
INSERT INTO users VALUES("13","jjj","test@test.com","$2y$10$/Qx3gHWYWUhlF1aPfzXaCeZA7fRzfSEyCIOnk/dcC4ejO8PsoaalG","","1213","","1","","","0","1","2019-01-02 17:08:31","2019-03-02 21:02:29");
INSERT INTO users VALUES("19","shakalaka","shakalaka@gmail.com","$2y$10$ketLWT0Ib/JXpo00eJlxoeSw.7leS8V1CUGInfbyOWT4F5.Xuo7S2","","1212","Digital image","5","","","0","1","2020-11-08 17:07:16","2023-03-17 17:11:29");
INSERT INTO users VALUES("21","modon","modon@gmail.com","$2y$10$7VpoeGMkP8QCvL5zLwFW..6MYJ5MRumDLDoX.TTQtClS561rpFHY.","","2222","modon company","5","","","0","1","2020-11-13 00:12:08","2023-03-17 17:11:29");
INSERT INTO users VALUES("22","dhiman","dhiman@gmail.com","$2y$10$3mPygsC6wwnDtw/Sg85IpuExtUhgaHx52Lwp7Rz0.FNfuFdfKVpRq","","+8801111111101","lioncoders","5","","","0","1","2020-11-14 23:14:58","2023-03-21 23:01:13");
INSERT INTO users VALUES("31","mbs","mbs@gmail.com","$2y$10$6Ldm1rWEVSrlTmpjIXkeQO9KwWJz/j0FB4U.fY1oCFeax47rvttEK","","2121","","4","1","2","0","1","2021-12-28 23:40:22","2023-03-17 17:11:29");
INSERT INTO users VALUES("39","maja","maja@maja.com","$2y$10$lrMVhNDE9AuKhFrJIgG2y.zdtrCltR8/JB1okO0W8GsUcMjSFW7rW","","444555","","4","5","2","0","1","2022-09-13 21:37:21","2023-03-17 17:11:29");
INSERT INTO users VALUES("40","Shamim","uksales@banglacarparts.com","$2y$10$yUqHsVZTDKBxblayGXLvxOunqO1sdyGSgLhmf6CJchIgx.sBc/eC6","","07739371171","Banglacar","2","","","1","0","2023-03-21 23:00:42","2023-03-21 23:06:36");
INSERT INTO users VALUES("41","Mahir","banglacarparts@gmail.com","$2y$10$Ux.BO9Qg2GAo/jDMedfnEOcD3ULTustsUvTibpG6D8OVIU6Zsiiae","","07947258297","Banglacar","2","","","1","0","2023-03-21 23:02:20","2023-03-21 23:02:20");
INSERT INTO users VALUES("42","sujonahmed","sujonahmed5284@gmail.com","$2y$10$T3h9RbbD6gCELZUmlnMQnebRTqRct/6t74eS8h06co/C06N0UF6ue","","01743405982","Largeit","5","","","1","0","2023-03-22 10:46:55","2023-03-22 10:49:57");
INSERT INTO users VALUES("43","Uzi11918","uzi11918@gmail.com","$2y$10$Rmuucn36aAVLvHp9TDRVDODfwTd8csdRzAILPnVrBYEylSC98lIHO","","07947303703","Bangla Car Parts BD","4","15","2","1","0","2023-04-24 15:52:57","2023-04-24 15:54:03");
INSERT INTO users VALUES("44","Cosmetics world","rizonlami@gmail.com","$2y$10$qhj9llentHLIg9VcztVYmOT3XiyFI3v3CYOtssU9gpxuHZb.o5lm2","","01711057659","Cosmetics world","5","15","2","1","0","2023-05-05 09:37:24","2023-05-05 09:39:44");



CREATE TABLE `variants` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=52 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO variants VALUES("2","Medium","2019-11-21 00:03:04","2019-11-24 01:43:52");
INSERT INTO variants VALUES("3","Small","2019-11-21 00:03:04","2019-11-24 01:43:52");
INSERT INTO variants VALUES("5","Large","2019-11-23 23:07:20","2019-11-24 01:44:56");
INSERT INTO variants VALUES("9","a","2020-05-18 09:44:14","2020-05-18 09:44:14");
INSERT INTO variants VALUES("11","b","2020-05-18 09:53:49","2020-05-18 09:53:49");
INSERT INTO variants VALUES("12","variant 1","2020-09-26 23:08:27","2020-09-26 23:08:27");
INSERT INTO variants VALUES("13","variant 2","2020-09-26 23:08:27","2020-09-26 23:08:27");
INSERT INTO variants VALUES("15","s","2020-11-15 23:09:33","2022-08-08 23:02:12");
INSERT INTO variants VALUES("16","m","2020-11-15 23:09:33","2022-08-08 23:02:12");
INSERT INTO variants VALUES("17","L","2020-11-15 23:09:33","2020-11-15 23:09:33");
INSERT INTO variants VALUES("18","s/red","2022-07-25 06:54:50","2022-07-25 06:54:50");
INSERT INTO variants VALUES("19","s/black","2022-07-25 06:54:50","2022-07-25 06:54:50");
INSERT INTO variants VALUES("20","m/red","2022-07-25 06:54:50","2022-07-25 06:54:50");
INSERT INTO variants VALUES("21","m/black","2022-07-25 06:54:50","2022-07-25 06:54:50");
INSERT INTO variants VALUES("22","l/red","2022-07-25 06:54:50","2022-07-25 06:54:50");
INSERT INTO variants VALUES("23","l/black","2022-07-25 06:54:50","2022-07-25 06:54:50");
INSERT INTO variants VALUES("24","s/blue","2022-08-02 22:25:19","2022-08-02 22:25:19");
INSERT INTO variants VALUES("25","m/blue","2022-08-02 22:25:20","2022-08-02 22:25:20");
INSERT INTO variants VALUES("26","l/blue","2022-08-02 22:25:20","2022-08-02 22:25:20");
INSERT INTO variants VALUES("27","s/green","2022-08-05 22:54:37","2022-08-05 22:54:37");
INSERT INTO variants VALUES("28","m/green","2022-08-05 22:54:37","2022-08-05 22:54:37");
INSERT INTO variants VALUES("29","l/green","2022-08-05 22:54:37","2022-08-05 22:54:37");
INSERT INTO variants VALUES("30","xl/red","2022-08-08 07:02:07","2022-08-08 07:02:07");
INSERT INTO variants VALUES("31","xl/blue","2022-08-08 07:02:07","2022-08-08 07:02:07");
INSERT INTO variants VALUES("32","xl/green","2022-08-08 07:02:07","2022-08-08 07:02:07");
INSERT INTO variants VALUES("33","red","2022-09-10 23:56:55","2022-09-10 23:56:55");
INSERT INTO variants VALUES("34","black","2022-09-10 23:56:55","2022-09-10 23:56:55");
INSERT INTO variants VALUES("35","blue","2022-09-10 23:56:55","2022-09-10 23:56:55");
INSERT INTO variants VALUES("36","black/12.5","2022-11-17 03:50:30","2022-11-17 03:50:30");
INSERT INTO variants VALUES("37","black/14","2022-11-17 03:50:30","2022-11-17 03:50:30");
INSERT INTO variants VALUES("38","black/15.6","2022-11-17 03:50:30","2022-11-17 03:50:30");
INSERT INTO variants VALUES("39","black/16","2022-11-17 03:50:30","2022-11-17 03:50:30");
INSERT INTO variants VALUES("40","gold/12.5","2022-11-17 03:50:30","2022-11-17 03:50:30");
INSERT INTO variants VALUES("41","gold/14","2022-11-17 03:50:30","2022-11-17 03:50:30");
INSERT INTO variants VALUES("42","gold/15.6","2022-11-17 03:50:30","2022-11-17 03:50:30");
INSERT INTO variants VALUES("43","gold/16","2022-11-17 03:50:30","2022-11-17 03:50:30");
INSERT INTO variants VALUES("44","silver/12.5","2022-11-17 03:50:30","2022-11-17 03:50:30");
INSERT INTO variants VALUES("45","silver/14","2022-11-17 03:50:30","2022-11-17 03:50:30");
INSERT INTO variants VALUES("46","silver/15.6","2022-11-17 03:50:30","2022-11-17 03:50:30");
INSERT INTO variants VALUES("47","silver/16","2022-11-17 03:50:30","2022-11-17 03:50:30");
INSERT INTO variants VALUES("48","metarial/12.5","2022-11-17 03:50:30","2022-11-17 03:50:30");
INSERT INTO variants VALUES("49","metarial/14","2022-11-17 03:50:30","2022-11-17 03:50:30");
INSERT INTO variants VALUES("50","metarial/15.6","2022-11-17 03:50:30","2022-11-17 03:50:30");
INSERT INTO variants VALUES("51","metarial/16","2022-11-17 03:50:30","2022-11-17 03:50:30");



CREATE TABLE `warehouses` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_active` tinyint(1) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO warehouses VALUES("1","UK Warehouse","02036092147","uksales@banglacarparts.com","Unit -6, 153-155 Ley Street, Ilford, IG1 4BL","1","2018-05-12 00:51:44","2023-03-21 20:01:03");
INSERT INTO warehouses VALUES("2","Dhaka Warehouse","07947258297","banglacarparts@gmail.com","Dhaka, Bangladesh","1","2018-05-12 01:09:03","2023-03-21 20:02:38");
INSERT INTO warehouses VALUES("3","test","","","dqwdeqw","0","2018-05-29 17:14:23","2018-05-29 17:14:47");
INSERT INTO warehouses VALUES("6","gudam","2121","","gazipur","0","2018-08-31 15:53:26","2018-08-31 15:54:48");

